# Daily Collection Management System — Phase 1 & 2 (core + database)

This package contains the **financial core** of the system: the part that must be correct before any screen is built.
It is **not** a finished app. See `docs/CHECKLIST.md` for exactly what is done, tested, untested and missing.

## What is in the box

| Path | What it is | Verified? |
|---|---|---|
| `src/money.ts`, `dates.ts` | Integer-centavo money, strict peso parsing, PHP formatting, Asia/Manila business dates | Tested (executed) |
| `src/schedule.ts` | Daily / weekly / biweekly / monthly / custom schedule generator, final adjusted installment, employer summary with no hidden fees | Tested (executed) |
| `src/installments.ts` | Days overdue, statuses (with grace period), account summary with separate figures | Tested (executed) |
| `src/allocation.ts` | Oldest-first allocation, partial, multi-installment, advance, overpayment to credit | Tested (executed) |
| `src/payments.ts` | Idempotent `recordPayment` + controlled `reversePayment`, authorization, validation, audit | Tested (executed, against an in-memory repository) |
| `src/receipt.ts` | Device-generated receipt numbers, server HMAC verification code, provisional vs cloud-confirmed view | Tested (executed) |
| `src/sync-queue.ts`, `sync-adapter.ts` | Offline queue: retry/backoff, duplicates, rejected/conflict surfacing | Tested (executed) |
| `src/reconciliation.ts`, `reports.ts` | Cash reconciliation formula; collection totals that reconcile to transactions | Tested (executed) |
| `src/repo.ts` | `Repo`/`Tx` interface + in-memory implementation for tests | Tested (executed) |
| `db/migrations/001_init.sql` | Full PostgreSQL schema, constraints, immutability triggers, Row Level Security | **Written, NOT executed** |
| `src/route.ts`, `dashboard.ts`, `shift.ts` | Daily route and stop progress, employee/employer dashboard maths, unusual-payment flags, shift cash figures | Tested (executed) |
| `api/`, `db/migrations/002_auth_and_fixes.sql` | HTTP API (login, customers, contracts, payments, sync, reports) and secure login functions | **Written, NOT run** |
| `.env.example` | Environment variables (no real secrets) | n/a |

Run the tests (Node 22.6 or newer, no installs needed): `npm test`

## Important design decisions

- **Money is integer centavos everywhere.** No floats. The DB uses `bigint` with CHECK constraints.
- **One payment = one device-generated `deviceTransactionId` + one `receiptNo`.** Both are UNIQUE per business in the database, so retries and two devices cannot create two payments.
- **Confirmed payments are immutable** (DB triggers block UPDATE/DELETE). Corrections are `payment_reversals` rows with a mandatory reason, user and time.
- **Offline receipts have no verification code** until synced, because the signing secret must never be in the phone. They show a "LOCALLY RECORDED" notice, and keep the same receipt number after sync.
- **Row Level Security** isolates businesses and limits employees to their own customers/records at the database level. The API must connect as a non-owner role and set `app.business_id`, `app.user_id`, `app.role` at the start of each transaction (see comments in the SQL). Login lookups (by email, before the business is known) must go through a separate privileged path, e.g. a `SECURITY DEFINER` function.
- **Overdue rule:** days overdue = calendar days from due date to today (Asia/Manila) while a balance remains. An installment is flagged `overdue` only after the grace period; days overdue are still shown honestly during grace.
- **Known limits:** customer credit is stored but there is no "apply credit to new schedule" feature yet. An offline payment for a customer reassigned in the meantime is *rejected* (employee-scope rule) and must be surfaced to the employer for manual handling. Remaining-principal accounting is not implemented (only the contractual balance).

## How to finish the project (recommended order)

You can continue in this chat one phase at a time, or hand these to a developer. Each phase lists a ready prompt.

**Step 0 — Accounts (about 30 minutes, you do this)**
1. Create a GitHub account and a private repository; upload this folder.
2. Create a PostgreSQL database. Low-cost options: Supabase or Neon. *Check current pricing and backup terms yourself.* Free tiers usually have limited or no automated backups and may pause inactive projects, so for real payment records plan on a paid tier with daily backups.
3. Run the schema: open the database SQL editor, paste `db/migrations/001_init.sql`, run it. **Send me any error text and I will fix the SQL.**
4. Create an app database role without BYPASSRLS and not the table owner, with a strong password. Put the connection string in `.env` (never in the frontend).

**Phase 3 — Backend API** (Fastify or Express + TypeScript, Zod validation, `pg` or Drizzle/Kysely).
Prompt: *"Using the core in `src/`, build the PostgreSQL implementation of `Repo`/`Tx` (with SELECT … FOR UPDATE), and the API routes: first-employer setup with INITIAL_SETUP_SECRET, login/logout/sessions, employee signup + approval, customers, contracts + schedule generation, POST /payments, POST /sync, reversals, reports, exports. Set the RLS session variables on every transaction."*

**Phase 4 — Employee PWA** (Vite + React + TypeScript + vite-plugin-pwa + Dexie for IndexedDB).
Screens: dashboard with big "Start Collection", today's route, customer list, collect payment, receipts, expenses, cash handover, sync status. Use `generateReceiptNo` and `SyncQueue` from this package. Call `navigator.storage.persist()` so Android Chrome is less likely to evict offline data.

**Phase 5 — Employer dashboard** (same React app, role-gated; the server enforces access regardless of what the UI shows).

**Phase 6 — Maps and routes** (Leaflet + OpenStreetMap, free, no API key; "navigate" opens the Android maps app via a `geo:` or Google Maps link). Nearest-next ordering can be done on the device without a paid routing API.

**Phase 7 — Exports and PDF receipts** (`exceljs` for Excel, CSV for plain exports, `pdf-lib` or similar for receipts; share through the Web Share API).

**Phase 8 — Deployment** (e.g. Render/Railway/Fly.io for the API and static frontend, HTTPS automatic). Put secrets in the host's environment settings, not in the repository.

## Installing on Android (once the PWA exists)
1. Open the HTTPS address in Chrome on the phone. 2. Menu (⋮) → **Install app** / **Add to Home screen**. 3. Open it from the home screen and log in once while online so customers download. 4. Test: turn on airplane mode, record a payment, turn it off, and confirm it syncs. GPS and install both require HTTPS.
Employer dashboard: the same web address from any computer or phone browser, logged in as the employer.

## Backup and restore (PostgreSQL)
- Prefer the host's automated daily backups and test a restore into a *separate* database.
- Manual: `pg_dump --format=custom --no-owner "$DATABASE_URL" > backup-$(date +%F).dump`
- Restore into an empty database: `pg_restore --no-owner --dbname "$NEW_DATABASE_URL" backup-YYYY-MM-DD.dump`
- After restoring, run a check that the sum of `payments.amount_centavos` matches the previous report, and recreate the app role/grants.
- Keep copies outside the hosting provider. Restoration has **not** been tested here.

## Privacy (Philippine Data Privacy Act) — practical notes, not legal advice
Show a privacy notice before collecting customer data; get recorded consent for GPS and photos (the schema stores consent timestamps and refuses a photo without consent); collect only what you need; limit exports to the employer; set a retention period; secure devices. Ask a lawyer or your Data Protection Officer about registration and breach-notification duties for your size of business.

## Collection conduct
The system must not send threatening or public-shaming messages. Keep reminder templates neutral and polite.
