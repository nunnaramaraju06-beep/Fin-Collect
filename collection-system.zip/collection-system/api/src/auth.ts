import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { hash, verify } from '@node-rs/argon2';
import { ValidationError } from '../../src/errors.ts';

export const SESSION_HOURS = 12;
export const sha256 = (s: string) => createHash('sha256').update(s).digest('hex');
export const newToken = () => randomBytes(32).toString('base64url');

export function checkPasswordStrength(p: string) {
  if (p.length < 10) throw new ValidationError('Password must be at least 10 characters');
  if (p.length > 128) throw new ValidationError('Password is too long');
  if (/^(.)\1+$/.test(p)) throw new ValidationError('Password is too simple');
}
export const hashPassword = (p: string) => hash(p);           // argon2id with library defaults
// A real hash of a throwaway password, computed once, used only to keep login timing similar for unknown emails.
const DUMMY: Promise<string> = hash(randomBytes(16).toString('hex'));
export async function verifyPassword(stored: string | null, p: string): Promise<boolean> {
  if (!stored) { await verify(await DUMMY, p).catch(() => false); return false; }
  try { return await verify(stored, p); } catch { return false; }
}
export function safeEqual(a: string, b: string): boolean {
  const x = createHash('sha256').update(a).digest(), y = createHash('sha256').update(b).digest();
  return timingSafeEqual(x, y);
}
