import Fastify from 'fastify';
import cookie from '@fastify/cookie';
import formbody from '@fastify/formbody';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import type { FastifyReply, FastifyRequest } from 'fastify';
import { z, ZodError } from 'zod';
import { env } from './config.ts';
import { pool, withTx } from './db.ts';
import type { Ctx } from './db.ts';
import { PgRepo, loadPayments } from './pgRepo.ts';
import { SESSION_HOURS, checkPasswordStrength, hashPassword, newToken, safeEqual, sha256, verifyPassword } from './auth.ts';
import { PaymentService } from '../../src/payments.ts';
import { processPaymentOp } from '../../src/sync-adapter.ts';
import { describeSchedule, generateSchedule } from '../../src/schedule.ts';
import { daysOverdue, installmentStatus, outstanding, summarizeAccount } from '../../src/installments.ts';
import { summarizeCollections } from '../../src/reports.ts';
import { businessDate } from '../../src/dates.ts';
import { AppError, ForbiddenError, NotFoundError, ValidationError } from '../../src/errors.ts';
import type { Actor, Installment, Role } from '../../src/types.ts';
import type { QueuedOp } from '../../src/sync-queue.ts';

interface AuthCtx { userId: string; businessId: string; role: Role; fullName: string; employeeCode: string | null; tokenHash: string }
declare module 'fastify' { interface FastifyRequest { auth: AuthCtx | null } }

const app = Fastify({ trustProxy: true, logger: { level: 'info', redact: ['req.headers.cookie', 'req.headers.authorization'] }, bodyLimit: 1_000_000 });
await app.register(helmet);
await app.register(cookie);
await app.register(formbody);
await app.register(rateLimit, { max: 300, timeWindow: '1 minute' });
app.decorateRequest('auth', null);

// ---------- session authentication ----------
app.addHook('onRequest', async req => {
  const sid = req.cookies?.sid;
  if (!sid) return;
  const tokenHash = sha256(sid);
  const { rows } = await pool.query('select * from app_session_lookup($1)', [tokenHash]);
  const r = rows[0];
  if (r) req.auth = { userId: r.user_id, businessId: r.business_id, role: r.role, fullName: r.full_name, employeeCode: r.employee_code, tokenHash };
});
const guard = (...roles: Role[]) => async (req: FastifyRequest, reply: FastifyReply) => {
  if (!req.auth) return reply.code(401).send({ error: 'Please sign in' });
  if (roles.length && !roles.includes(req.auth.role)) return reply.code(403).send({ error: 'Not allowed' });
};
const ctxOf = (a: AuthCtx): Ctx => ({ businessId: a.businessId, userId: a.userId, role: a.role });
const actorOf = (a: AuthCtx): Actor => ({ userId: a.userId, businessId: a.businessId, role: a.role, employeeId: a.userId });
const paymentService = (a: AuthCtx) => new PaymentService(new PgRepo(ctxOf(a)), { verificationSecret: env.RECEIPT_VERIFICATION_SECRET });
const audit = (c: any, a: AuthCtx, action: string, entityType: string, entityId: string, detail: object = {}) =>
  c.query('insert into audit_logs (business_id, actor_user_id, action, entity_type, entity_id, detail) values ($1,$2,$3,$4,$5,$6)', [a.businessId, a.userId, action, entityType, entityId, JSON.stringify(detail)]);

app.setErrorHandler((err: any, req, reply) => {
  if (err instanceof ZodError) return reply.code(400).send({ error: 'Invalid input', details: err.issues.map(i => `${i.path.join('.')}: ${i.message}`) });
  if (err instanceof AppError) {
    const status = err instanceof ValidationError ? 400 : err instanceof ForbiddenError ? 403 : err instanceof NotFoundError ? 404 : 409;
    return reply.code(status).send({ error: err.message, code: err.code });
  }
  if (err?.code === '23505') return reply.code(409).send({ error: 'That record already exists' });
  if (err?.statusCode === 429) return reply.code(429).send({ error: 'Too many requests. Please wait and try again.' });
  req.log.error(err);
  return reply.code(500).send({ error: 'Server error. Please try again.' });
});

// ---------- first-time setup (one-time, protected by INITIAL_SETUP_SECRET) ----------
const setupSchema = z.object({ secret: z.string(), businessName: z.string().min(2).max(120), fullName: z.string().min(2).max(120), email: z.string().email().max(200), password: z.string() });
const esc = (s: string) => s.replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]!));
const page = (body: string) => `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Setup</title><body style="font-family:system-ui;max-width:28rem;margin:2rem auto;padding:0 1rem">${body}</body>`;
app.get('/setup', async (_req, reply) => {
  const done = (await pool.query('select exists(select 1 from businesses) as done')).rows[0].done;
  reply.type('text/html').send(done ? page('<h2>Setup already completed</h2>') : page(`<h2>Create the employer account</h2><form method="post" action="/setup">
    <p>Setup secret<br><input name="secret" type="password" required style="width:100%;padding:.6rem"></p>
    <p>Business name<br><input name="businessName" required style="width:100%;padding:.6rem"></p>
    <p>Your full name<br><input name="fullName" required style="width:100%;padding:.6rem"></p>
    <p>Email<br><input name="email" type="email" required style="width:100%;padding:.6rem"></p>
    <p>Password (10+ characters)<br><input name="password" type="password" minlength="10" required style="width:100%;padding:.6rem"></p>
    <button style="padding:.8rem 1.2rem;font-size:1rem">Create employer account</button></form>`));
});
app.post('/setup', { config: { rateLimit: { max: 5, timeWindow: '15 minutes' } } }, async (req, reply) => {
  const b = setupSchema.parse(req.body);
  if (!safeEqual(b.secret, env.INITIAL_SETUP_SECRET)) return reply.code(403).type('text/html').send(page('<h2>Wrong setup secret</h2>'));
  checkPasswordStrength(b.password);
  try {
    await pool.query('select app_setup_first_employer($1,$2,$3,$4)', [b.businessName.trim(), b.email.trim().toLowerCase(), b.fullName.trim(), await hashPassword(b.password)]);
  } catch (e: any) {
    if (/already set up/.test(e?.message ?? '')) return reply.code(409).type('text/html').send(page('<h2>Setup already completed</h2>'));
    throw e;
  }
  reply.type('text/html').send(page(`<h2>Done</h2><p>Employer account created for ${esc(b.email)}. You can now sign in through the app. Remove INITIAL_SETUP_SECRET from your host settings.</p>`));
});

// ---------- auth ----------
app.get('/health', async () => ({ ok: true }));
const loginSchema = z.object({ email: z.string().email().max(200), password: z.string().min(1).max(200) });
app.post('/api/auth/login', { config: { rateLimit: { max: 10, timeWindow: '1 minute' } } }, async (req, reply) => {
  const b = loginSchema.parse(req.body);
  const u = (await pool.query('select * from app_login_lookup($1)', [b.email.trim()])).rows[0];
  const generic = () => reply.code(401).send({ error: 'Invalid email or password' });
  if (!u) { await verifyPassword(null, b.password); return generic(); }
  if (u.locked_until && new Date(u.locked_until) > new Date()) return reply.code(429).send({ error: 'Too many failed attempts. Try again in 15 minutes.' });
  const ok = await verifyPassword(u.password_hash, b.password);
  await pool.query('select app_record_login($1,$2)', [u.id, ok]);
  if (!ok) return generic();
  if (u.status === 'pending') return reply.code(403).send({ error: 'Your account is waiting for employer approval.' });
  if (u.status !== 'active') return reply.code(403).send({ error: 'This account is not active. Contact your employer.' });
  const token = newToken();
  await pool.query('select app_create_session($1,$2,$3,$4,$5)', [u.id, sha256(token), new Date(Date.now() + SESSION_HOURS * 3600_000), req.ip, req.headers['user-agent'] ?? '']);
  reply.setCookie('sid', token, { httpOnly: true, secure: env.NODE_ENV === 'production', sameSite: 'strict', path: '/', maxAge: SESSION_HOURS * 3600 });
  return { ok: true, role: u.role, fullName: u.full_name };
});
app.post('/api/auth/logout', async (req, reply) => {
  if (req.auth) await pool.query('select app_revoke_session($1)', [req.auth.tokenHash]);
  reply.clearCookie('sid', { path: '/' });
  return { ok: true };
});
app.get('/api/auth/me', { preHandler: guard() }, async req => ({ userId: req.auth!.userId, role: req.auth!.role, fullName: req.auth!.fullName, employeeCode: req.auth!.employeeCode }));

app.post('/api/auth/signup', { config: { rateLimit: { max: 5, timeWindow: '1 hour' } } }, async (req, reply) => {
  const b = z.object({ fullName: z.string().min(2).max(120), mobile: z.string().min(7).max(20), email: z.string().email().max(200), password: z.string() }).parse(req.body);
  checkPasswordStrength(b.password);
  try { await pool.query('select app_register_employee($1,$2,$3,$4)', [b.email.trim().toLowerCase(), b.fullName.trim(), b.mobile.trim(), await hashPassword(b.password)]); }
  catch (e: any) { if (e?.code !== '23505') throw e; }          // same response whether or not the email exists
  return reply.code(202).send({ ok: true, message: 'Request received. The employer must approve your account before you can sign in.' });
});
app.post('/api/auth/change-password', { preHandler: guard() }, async (req, reply) => {
  const b = z.object({ currentPassword: z.string(), newPassword: z.string() }).parse(req.body);
  checkPasswordStrength(b.newPassword);
  const a = req.auth!;
  const row = await withTx(ctxOf(a), async c => (await c.query('select password_hash from users where id=$1', [a.userId])).rows[0]);
  if (!(await verifyPassword(row?.password_hash ?? null, b.currentPassword))) return reply.code(403).send({ error: 'Current password is incorrect' });
  const newHash = await hashPassword(b.newPassword);
  await withTx(ctxOf(a), async c => {
    await c.query('update users set password_hash=$1, updated_at=now() where id=$2', [newHash, a.userId]);
    await c.query('update sessions set revoked_at=now() where user_id=$1 and token_hash<>$2 and revoked_at is null', [a.userId, a.tokenHash]);
    await audit(c, a, 'user.password_changed', 'user', a.userId);
  });
  return { ok: true };
});

// ---------- employees (employer) ----------
app.get('/api/employees', { preHandler: guard('employer', 'accountant') }, async req =>
  withTx(ctxOf(req.auth!), async c => (await c.query(
    `select u.id, u.full_name, u.email, u.mobile, u.status, e.employee_code, u.created_at from users u left join employee_profiles e on e.user_id=u.id where u.role='employee' order by u.created_at`)).rows));
app.post('/api/employees/:id/approve', { preHandler: guard('employer') }, async req => {
  const id = z.string().uuid().parse((req.params as any).id); const a = req.auth!;
  return withTx(ctxOf(a), async c => {
    const r = await c.query(`update users set status='active', updated_at=now() where id=$1 and role='employee' and status='pending' returning id`, [id]);
    if (r.rowCount !== 1) throw new NotFoundError('No pending employee with that id');
    const code = (await c.query(`select 'EMP-' || lpad(nextval('employee_code_seq')::text, 3, '0') as code`)).rows[0].code;
    await c.query('insert into employee_profiles (user_id, business_id, employee_code, approved_by, approved_at) values ($1,$2,$3,$4,now())', [id, a.businessId, code, a.userId]);
    await audit(c, a, 'employee.approved', 'user', id, { employeeCode: code });
    return { ok: true, employeeCode: code };
  });
});
app.post('/api/employees/:id/status', { preHandler: guard('employer') }, async req => {
  const id = z.string().uuid().parse((req.params as any).id); const a = req.auth!;
  const { status } = z.object({ status: z.enum(['active', 'suspended', 'deactivated']) }).parse(req.body);
  return withTx(ctxOf(a), async c => {
    const r = await c.query(`update users set status=$1, updated_at=now() where id=$2 and role='employee' and status<>'pending' returning id`, [status, id]);
    if (r.rowCount !== 1) throw new NotFoundError('Employee not found (or still pending: use approve)');
    if (status !== 'active') await c.query('update sessions set revoked_at=now() where user_id=$1 and revoked_at is null', [id]); // takes effect on the server immediately
    await audit(c, a, `employee.${status}`, 'user', id);
    return { ok: true };
  });
});

// ---------- customers ----------
const customerSchema = z.object({
  fullName: z.string().min(2).max(160), mobile: z.string().max(20).nullish(), altMobile: z.string().max(20).nullish(),
  address: z.string().max(300).nullish(), barangay: z.string().max(100).nullish(), municipality: z.string().max(100).nullish(), province: z.string().max(100).nullish(),
  latitude: z.number().min(-90).max(90).nullish(), longitude: z.number().min(-180).max(180).nullish(),
  locationConsent: z.boolean().default(false), assignedEmployeeId: z.string().uuid().nullish(),
});
app.post('/api/customers', { preHandler: guard('employer', 'employee') }, async (req, reply) => {
  const b = customerSchema.parse(req.body); const a = req.auth!;
  if ((b.latitude != null || b.longitude != null) && !b.locationConsent) throw new ValidationError('Customer consent is required to record a GPS location');
  if ((b.latitude == null) !== (b.longitude == null)) throw new ValidationError('Provide both latitude and longitude');
  const assignee = a.role === 'employee' ? a.userId : (b.assignedEmployeeId ?? null);
  const row = await withTx(ctxOf(a), async c => {
    const r = await c.query(
      `insert into customers (business_id, customer_code, full_name, mobile, alt_mobile, address, barangay, municipality, province, latitude, longitude, location_consent_at,
         status, assigned_employee_id, created_by)
       values ($1, 'C' || lpad(nextval('customer_code_seq')::text, 6, '0'), $2,$3,$4,$5,$6,$7,$8,$9,$10, $11, 'prospect', $12, $13) returning id, customer_code`,
      [a.businessId, b.fullName, b.mobile ?? null, b.altMobile ?? null, b.address ?? null, b.barangay ?? null, b.municipality ?? null, b.province ?? null,
       b.latitude ?? null, b.longitude ?? null, b.locationConsent && b.latitude != null ? new Date() : null, assignee, a.userId]);
    if (assignee) await c.query('insert into customer_assignments (business_id, customer_id, employee_id, assigned_by) values ($1,$2,$3,$4)', [a.businessId, r.rows[0].id, assignee, a.userId]);
    await audit(c, a, 'customer.created', 'customer', r.rows[0].id, { code: r.rows[0].customer_code });
    return r.rows[0];
  });
  return reply.code(201).send({ id: row.id, customerCode: row.customer_code, status: 'prospect' });
});
app.get('/api/customers', { preHandler: guard() }, async req => {
  const q = z.object({ status: z.enum(['prospect', 'active', 'completed', 'inactive', 'disputed']).optional(), search: z.string().max(80).optional() }).parse(req.query);
  return withTx(ctxOf(req.auth!), async c => (await c.query(
    `select id, customer_code, full_name, mobile, barangay, municipality, status, assigned_employee_id, latitude, longitude from customers
     where ($1::text is null or status=$1) and ($2::text is null or full_name ilike '%'||$2||'%' or customer_code ilike $2||'%') order by full_name limit 500`,
    [q.status ?? null, q.search ?? null])).rows);
});
app.post('/api/customers/:id/reassign', { preHandler: guard('employer') }, async req => {
  const id = z.string().uuid().parse((req.params as any).id); const a = req.auth!;
  const { employeeId } = z.object({ employeeId: z.string().uuid() }).parse(req.body);
  return withTx(ctxOf(a), async c => {
    const emp = await c.query(`select id from users where id=$1 and role='employee' and status='active'`, [employeeId]);
    if (emp.rowCount !== 1) throw new NotFoundError('Active employee not found');
    const r = await c.query('update customers set assigned_employee_id=$1 where id=$2', [employeeId, id]);
    if (r.rowCount !== 1) throw new NotFoundError('Customer not found');
    await c.query('update customer_assignments set unassigned_at=now() where customer_id=$1 and unassigned_at is null', [id]);
    await c.query('insert into customer_assignments (business_id, customer_id, employee_id, assigned_by) values ($1,$2,$3,$4)', [a.businessId, id, employeeId, a.userId]);
    await audit(c, a, 'customer.reassigned', 'customer', id, { to: employeeId });
    return { ok: true };
  });
});

// ---------- contracts & schedules (employer). dryRun=true shows the summary WITHOUT saving ----------
const contractSchema = z.object({
  frequency: z.enum(['daily', 'weekly', 'biweekly', 'monthly', 'custom']), firstDueDate: z.string(),
  totalAmount: z.number().int().positive(), installmentAmount: z.number().int().positive().optional(), installmentCount: z.number().int().positive().optional(),
  customDueDates: z.array(z.string()).optional(), skipSundays: z.boolean().optional(),
  principalAmount: z.number().int().positive().optional(), graceDays: z.number().int().min(0).max(60).default(0), dryRun: z.boolean().default(true),
});
app.post('/api/customers/:id/contract', { preHandler: guard('employer') }, async req => {
  const id = z.string().uuid().parse((req.params as any).id); const a = req.auth!; const b = contractSchema.parse(req.body);
  const plan = generateSchedule(b);
  const summary = describeSchedule(plan);
  if (b.dryRun) return { dryRun: true, summary, installments: plan };
  return withTx(ctxOf(a), async c => {
    const cust = (await c.query('select status from customers where id=$1 for update', [id])).rows[0];
    if (!cust) throw new NotFoundError('Customer not found');
    if ((await c.query(`select 1 from contracts where customer_id=$1 and status='active'`, [id])).rowCount) throw new AppError('CONFLICT', 'Customer already has an active contract');
    const k = (await c.query(
      `insert into contracts (business_id, customer_id, principal_centavos, total_contract_centavos, frequency, installment_centavos, start_date, end_date, grace_days, status, approved_by, approved_at)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,'active',$10,now()) returning id`,
      [a.businessId, id, b.principalAmount ?? null, b.totalAmount, b.frequency, b.installmentAmount ?? plan[0].amount, plan[0].dueDate, plan[plan.length - 1].dueDate, b.graceDays, a.userId])).rows[0];
    const sch = (await c.query('insert into payment_schedules (business_id, contract_id, params, generated_by) values ($1,$2,$3,$4) returning id', [a.businessId, k.id, JSON.stringify(b), a.userId])).rows[0];
    for (const p of plan) {
      await c.query('insert into installments (business_id, contract_id, customer_id, schedule_id, sequence, due_date, scheduled_centavos) values ($1,$2,$3,$4,$5,$6,$7)',
        [a.businessId, k.id, id, sch.id, p.sequence, p.dueDate, p.amount]);
    }
    await c.query(`update customers set status='active', approved_by=$1, approved_at=now() where id=$2`, [a.userId, id]);
    await audit(c, a, 'contract.activated', 'contract', k.id, { total: b.totalAmount, installments: plan.length });
    return { dryRun: false, contractId: k.id, summary };
  });
});
app.get('/api/customers/:id/account', { preHandler: guard() }, async req => {
  const id = z.string().uuid().parse((req.params as any).id);
  return withTx(ctxOf(req.auth!), async c => {
    const cust = (await c.query('select id, customer_code, full_name, mobile, status, credit_centavos from customers where id=$1', [id])).rows[0];
    if (!cust) throw new NotFoundError('Customer not found');   // also what an employee sees for someone else's customer
    const grace = (await c.query(`select grace_days from contracts where customer_id=$1 and status='active' limit 1`, [id])).rows[0]?.grace_days ?? 0;
    const today = businessDate();
    const list: Installment[] = (await c.query('select * from installments where customer_id=$1 order by due_date, sequence', [id])).rows.map(r => ({
      id: r.id, customerId: r.customer_id, sequence: r.sequence, dueDate: r.due_date, scheduledAmount: r.scheduled_centavos, allocatedAmount: r.allocated_centavos,
      lastPaymentDate: r.last_payment_date ?? null, state: r.state }));
    return { customer: cust, today, summary: summarizeAccount(list, today, grace),
      installments: list.map(i => ({ ...i, outstanding: outstanding(i), daysOverdue: daysOverdue(i, today), status: installmentStatus(i, today, grace) })) };
  });
});

// ---------- payments ----------
const paymentSchema = z.object({
  customerId: z.string().uuid(), employeeId: z.string().uuid().optional(),
  amount: z.number().int().positive().max(10_000_000_000), method: z.enum(['cash', 'bank_transfer', 'e_wallet', 'other']),
  paidAt: z.string().max(40), deviceTransactionId: z.string().min(8).max(100), receiptNo: z.string().min(5).max(60),
  reference: z.string().max(100).nullish(), note: z.string().max(500).nullish(),
  location: z.object({ lat: z.number(), lng: z.number(), accuracyM: z.number().optional(), capturedAt: z.string() }).nullish(),
  recordedOffline: z.boolean().default(false),
});
function toPaymentInput(a: AuthCtx, raw: unknown) {
  const b = paymentSchema.parse(raw);
  const employeeId = b.employeeId ?? (a.role === 'employee' ? a.userId : undefined);
  if (!employeeId) throw new ValidationError('employeeId is required when an employer records a payment');
  return { ...b, employeeId, businessId: a.businessId };
}
app.post('/api/payments', { preHandler: guard('employer', 'employee') }, async (req, reply) => {
  const a = req.auth!;
  const { payment, duplicate } = await paymentService(a).recordPayment(actorOf(a), toPaymentInput(a, req.body));
  return reply.code(duplicate ? 200 : 201).send({ duplicate, payment });
});
app.post('/api/payments/:id/reverse', { preHandler: guard('employer') }, async req => {
  const a = req.auth!; const id = z.string().uuid().parse((req.params as any).id);
  const { reason } = z.object({ reason: z.string().min(5).max(300) }).parse(req.body);
  return paymentService(a).reversePayment(actorOf(a), { businessId: a.businessId, paymentId: id, reason });
});

// ---------- offline sync: one request can carry many queued operations ----------
app.post('/api/sync', { preHandler: guard('employer', 'employee') }, async req => {
  const a = req.auth!;
  const b = z.object({ deviceCode: z.string().max(60).optional(), ops: z.array(z.object({ opId: z.string().min(8).max(100), type: z.string(), payload: z.unknown(), createdAt: z.string().optional() })).max(100) }).parse(req.body);
  const svc = paymentService(a);
  const results: { opId: string; status: string; message?: string }[] = [];
  for (const op of b.ops) {           // oldest first, as sent. An unexpected error aborts the request (HTTP 500) and the client retries safely.
    let r: { kind: string; message?: string };
    if (op.type !== 'payment') r = { kind: 'rejected', message: `Unsupported operation type "${op.type}" (not built yet)` };
    else {
      try {
        const payload = toPaymentInput(a, op.payload);
        r = await processPaymentOp(svc, actorOf(a), { opId: op.opId, type: 'payment', payload, createdAt: op.createdAt ?? '', status: 'pending', attempts: 0 } as QueuedOp);
      } catch (e) {
        if (e instanceof ZodError || e instanceof ValidationError) r = { kind: 'rejected', message: e instanceof ZodError ? 'Invalid payment data' : e.message };
        else throw e;
      }
    }
    const status = r.kind === 'ok' ? 'synced' : r.kind;
    await withTx(ctxOf(a), c => c.query(
      `insert into sync_operations (business_id, user_id, device_code, op_id, op_type, status, error) values ($1,$2,$3,$4,$5,$6,$7) on conflict (business_id, op_id) do nothing`,
      [a.businessId, a.userId, b.deviceCode ?? null, op.opId, op.type, status, r.message ?? null]));
    results.push({ opId: op.opId, status, message: r.message });
  }
  return { results };
});

// ---------- reports ----------
app.get('/api/reports/collections', { preHandler: guard('employer', 'accountant') }, async req => {
  const q = z.object({ from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), employeeId: z.string().uuid().optional() }).parse(req.query);
  return withTx(ctxOf(req.auth!), async c => {
    const payments = await loadPayments(c,
      `paid_at >= (($1::date)::timestamp at time zone 'Asia/Manila') and paid_at < ((($2::date + 1))::timestamp at time zone 'Asia/Manila')`, [q.from, q.to]);
    const reversed = new Set<string>((await c.query('select payment_id from payment_reversals')).rows.map((r: { payment_id: string }) => r.payment_id));
    return summarizeCollections(payments, reversed, q.from, q.to, q.employeeId);
  });
});

await app.listen({ port: env.PORT, host: '0.0.0.0' });
