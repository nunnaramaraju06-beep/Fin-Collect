import pg from 'pg';
import { env } from './config.ts';
import type { Role } from '../../src/types.ts';

pg.types.setTypeParser(20, v => Number(v));   // bigint -> number (centavos stay well below 2^53)
pg.types.setTypeParser(1082, v => v);         // date -> 'YYYY-MM-DD' string (no timezone shifting)
export const pool = new pg.Pool({ connectionString: env.DATABASE_URL, max: 10, idleTimeoutMillis: 30000 });

export interface Ctx { businessId: string; userId: string; role: Role }

/** Every request runs in a transaction that tells PostgreSQL who is asking, so Row Level Security applies. */
export async function withTx<T>(ctx: Ctx, fn: (c: pg.PoolClient) => Promise<T>): Promise<T> {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    await c.query(`select set_config('app.business_id',$1,true), set_config('app.user_id',$2,true), set_config('app.role',$3,true)`,
      [ctx.businessId, ctx.userId, ctx.role]);
    const r = await fn(c);
    await c.query('COMMIT');
    return r;
  } catch (e) {
    try { await c.query('ROLLBACK'); } catch { /* ignore */ }
    throw e;
  } finally { c.release(); }
}
