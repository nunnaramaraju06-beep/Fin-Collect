import type pg from 'pg';
import { withTx } from './db.ts';
import type { Ctx } from './db.ts';
import type { Repo, Tx } from '../../src/repo.ts';
import type { Allocation, AuditEntry, CustomerRef, Installment, PaymentRecord, Reversal } from '../../src/types.ts';

type Row = Record<string, any>;
const iso = (d: Date | string | null | undefined): string => (d instanceof Date ? d.toISOString() : String(d));

function mapPayment(r: Row, allocs: Row[]): PaymentRecord {
  return {
    id: r.id, businessId: r.business_id, customerId: r.customer_id, employeeId: r.employee_id,
    amount: r.amount_centavos, method: r.method, paidAt: iso(r.paid_at),
    deviceTransactionId: r.device_transaction_id, receiptNo: r.receipt_no, verificationCode: r.verification_code,
    reference: r.reference_no, note: r.note,
    location: r.latitude == null ? null : { lat: Number(r.latitude), lng: Number(r.longitude), accuracyM: r.location_accuracy_m ?? undefined, capturedAt: iso(r.location_captured_at ?? r.paid_at) },
    recordedOffline: r.recorded_offline, syncedAt: iso(r.synced_at),
    allocations: allocs.map(a => ({ installmentId: a.installment_id, amount: a.amount_centavos, kind: a.kind }) as Allocation),
    creditAmount: r.credit_centavos,
  };
}
async function loadPayments(c: pg.PoolClient, where: string, params: unknown[]): Promise<PaymentRecord[]> {
  const { rows } = await c.query(`select * from payments where ${where}`, params);
  if (rows.length === 0) return [];
  const al = await c.query('select * from payment_allocations where payment_id = any($1::uuid[])', [rows.map(r => r.id)]);
  return rows.map(r => mapPayment(r, al.rows.filter(a => a.payment_id === r.id)));
}
export { loadPayments };

function makeTx(c: pg.PoolClient): Tx {
  return {
    async getCustomer(b, id): Promise<CustomerRef | null> {
      const { rows } = await c.query('select id, business_id, assigned_employee_id, status, credit_centavos from customers where id=$1 and business_id=$2 for update', [id, b]);
      const r = rows[0]; if (!r) return null;
      return { id: r.id, businessId: r.business_id, assignedEmployeeId: r.assigned_employee_id, status: r.status, creditBalance: r.credit_centavos };
    },
    async listInstallments(b, customerId): Promise<Installment[]> {
      const { rows } = await c.query('select * from installments where business_id=$1 and customer_id=$2 order by due_date, sequence for update', [b, customerId]);
      return rows.map(r => ({ id: r.id, customerId: r.customer_id, sequence: r.sequence, dueDate: r.due_date, scheduledAmount: r.scheduled_centavos,
        allocatedAmount: r.allocated_centavos, lastPaymentDate: r.last_payment_date ?? null, state: r.state }));
    },
    async saveInstallments(b, list) {
      for (const i of list) {
        const r = await c.query('update installments set allocated_centavos=$1, last_payment_date=$2 where id=$3 and business_id=$4', [i.allocatedAmount, i.lastPaymentDate, i.id, b]);
        if (r.rowCount !== 1) throw new Error('installment update failed');
      }
    },
    async setCustomerCredit(b, id, credit) {
      const r = await c.query('update customers set credit_centavos=$1 where id=$2 and business_id=$3', [credit, id, b]);
      if (r.rowCount !== 1) throw new Error('customer credit update failed');
    },
    async findPaymentByDeviceTxn(b, key) { return (await loadPayments(c, 'business_id=$1 and device_transaction_id=$2', [b, key]))[0] ?? null; },
    async findPaymentByReceiptNo(b, no) { return (await loadPayments(c, 'business_id=$1 and receipt_no=$2', [b, no]))[0] ?? null; },
    async findPayment(b, id) { return (await loadPayments(c, 'business_id=$1 and id=$2', [b, id]))[0] ?? null; },
    async listCustomerPayments(b, customerId) { return loadPayments(c, 'business_id=$1 and customer_id=$2', [b, customerId]); },
    async insertPayment(p: PaymentRecord) {
      await c.query(
        `insert into payments (id, business_id, customer_id, employee_id, amount_centavos, credit_centavos, method, paid_at, device_transaction_id,
           receipt_no, verification_code, reference_no, note, latitude, longitude, location_accuracy_m, location_captured_at, recorded_offline, synced_at)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)`,
        [p.id, p.businessId, p.customerId, p.employeeId, p.amount, p.creditAmount, p.method, p.paidAt, p.deviceTransactionId, p.receiptNo, p.verificationCode,
         p.reference, p.note, p.location?.lat ?? null, p.location?.lng ?? null, p.location?.accuracyM != null ? Math.round(p.location.accuracyM) : null,
         p.location?.capturedAt ?? null, p.recordedOffline, p.syncedAt]);
      for (const a of p.allocations) {
        await c.query('insert into payment_allocations (business_id, payment_id, installment_id, amount_centavos, kind) values ($1,$2,$3,$4,$5)',
          [p.businessId, p.id, a.installmentId, a.amount, a.kind]);
      }
      await c.query('insert into receipts (business_id, payment_id, receipt_no, verification_code) values ($1,$2,$3,$4)', [p.businessId, p.id, p.receiptNo, p.verificationCode]);
    },
    async getReversal(b, paymentId): Promise<Reversal | null> {
      const { rows } = await c.query('select * from payment_reversals where business_id=$1 and payment_id=$2', [b, paymentId]);
      const r = rows[0]; if (!r) return null;
      return { id: r.id, businessId: r.business_id, paymentId: r.payment_id, reason: r.reason, reversedBy: r.reversed_by, reversedAt: iso(r.reversed_at) };
    },
    async insertReversal(r: Reversal) {
      await c.query('insert into payment_reversals (id, business_id, payment_id, reason, reversed_by, reversed_at) values ($1,$2,$3,$4,$5,$6)',
        [r.id, r.businessId, r.paymentId, r.reason, r.reversedBy, r.reversedAt]);
    },
    async audit(e: AuditEntry) {
      await c.query('insert into audit_logs (business_id, actor_user_id, action, entity_type, entity_id, detail, created_at) values ($1,$2,$3,$4,$5,$6,$7)',
        [e.businessId, e.actorUserId, e.action, e.entityType, e.entityId, JSON.stringify(e.detail), e.at]);
    },
  };
}

/** One PgRepo per request: all of its transactions run under that request's user context (Row Level Security). */
export class PgRepo implements Repo {
  ctx: Ctx;
  constructor(ctx: Ctx) { this.ctx = ctx; }
  transaction<T>(fn: (tx: Tx) => Promise<T>): Promise<T> { return withTx(this.ctx, c => fn(makeTx(c))); }
}
