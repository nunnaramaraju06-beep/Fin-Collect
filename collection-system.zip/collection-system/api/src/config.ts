import { z } from 'zod';
const schema = z.object({
  NODE_ENV: z.string().default('development'),
  PORT: z.coerce.number().default(3000),
  DATABASE_URL: z.string().min(10),
  INITIAL_SETUP_SECRET: z.string().min(16, 'INITIAL_SETUP_SECRET must be at least 16 characters'),
  RECEIPT_VERIFICATION_SECRET: z.string().min(16, 'RECEIPT_VERIFICATION_SECRET must be at least 16 characters'),
});
export const env = schema.parse(process.env);
