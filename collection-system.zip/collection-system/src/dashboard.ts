import { businessDate, startOfMonth, startOfWeek } from './dates.ts';
import type { RouteStop } from './route.ts';
import type { PaymentMethod, PaymentRecord } from './types.ts';

const dayOf = (p: PaymentRecord) => businessDate(new Date(p.paidAt));
const sum = (ps: PaymentRecord[]) => ps.reduce((s, p) => s + p.amount, 0);
const inRange = (ps: PaymentRecord[], from: string, to: string) => ps.filter(p => { const d = dayOf(p); return d >= from && d <= to; });
const pct = (part: number, whole: number) => (whole > 0 ? Math.round((part / whole) * 100) : 0);
const live = (ps: PaymentRecord[], reversed: Set<string>) => ps.filter(p => !reversed.has(p.id));

export interface EmployeeDashboardInput {
  today: string; employeeId: string; dailyTarget: number; payments: PaymentRecord[]; reversedIds: Set<string>;
  customers: { customerId: string; dueTodayAmount: number; overdueAmount: number; followUpDate?: string | null }[];
  stops: RouteStop[]; pendingOffline: number; lastSyncAt: string | null;
}
export function employeeDashboard(i: EmployeeDashboardInput) {
  const mine = live(i.payments, i.reversedIds).filter(p => p.employeeId === i.employeeId);
  const todays = inRange(mine, i.today, i.today);
  const collectedToday = sum(todays);
  return {
    assignedToday: i.stops.length,
    visited: i.stops.filter(s => s.status === 'visited').length,
    successfulCollections: new Set(todays.map(p => p.customerId)).size,
    failedAttempts: i.stops.filter(s => s.status === 'skipped').length,
    toVisit: i.stops.filter(s => s.status === 'pending').length,
    dailyTarget: i.dailyTarget, targetPercent: pct(collectedToday, i.dailyTarget),
    collectedToday, collectedWeek: sum(inRange(mine, startOfWeek(i.today), i.today)), collectedMonth: sum(inRange(mine, startOfMonth(i.today), i.today)),
    cashCollectedToday: sum(todays.filter(p => p.method === 'cash')), nonCashCollectedToday: sum(todays.filter(p => p.method !== 'cash')),
    amountDueToday: i.customers.reduce((s, c) => s + c.dueTodayAmount, 0), totalOverdue: i.customers.reduce((s, c) => s + c.overdueAmount, 0),
    followUpsRequired: i.customers.filter(c => c.followUpDate && c.followUpDate <= i.today).length,
    pendingOffline: i.pendingOffline, lastSyncAt: i.lastSyncAt,
  };
}

export interface CustomerRow { customerId: string; employeeId: string | null; status: 'prospect' | 'active' | 'completed' | 'inactive' | 'disputed';
  municipality: string | null; barangay: string | null; outstanding: number; dueTodayAmount: number; overdueAmount: number }
export interface EmployerFilters { from?: string; to?: string; employeeId?: string; barangay?: string; municipality?: string; status?: CustomerRow['status']; method?: PaymentMethod }
export interface EmployerDashboardInput { today: string; customers: CustomerRow[]; payments: PaymentRecord[]; reversedIds: Set<string>; dailyTargets: Record<string, number>; filters?: EmployerFilters }

export function employerDashboard(i: EmployerDashboardInput) {
  const f = i.filters ?? {};
  const custs = i.customers.filter(c => (!f.employeeId || c.employeeId === f.employeeId) && (!f.barangay || c.barangay === f.barangay)
    && (!f.municipality || c.municipality === f.municipality) && (!f.status || c.status === f.status));
  const customerFilterOn = !!(f.barangay || f.municipality || f.status);
  const ids = new Set(custs.map(c => c.customerId));
  const pays = live(i.payments, i.reversedIds).filter(p => (!f.employeeId || p.employeeId === f.employeeId) && (!f.method || p.method === f.method) && (!customerFilterOn || ids.has(p.customerId)));
  const from = f.from ?? startOfMonth(i.today), to = f.to ?? i.today;
  const range = inRange(pays, from, to);
  const methods: Record<PaymentMethod, number> = { cash: 0, bank_transfer: 0, e_wallet: 0, other: 0 };
  for (const p of range) methods[p.method] += p.amount;
  const todays = inRange(pays, i.today, i.today), month = inRange(pays, startOfMonth(i.today), i.today);
  const employees = [...new Set([...Object.keys(i.dailyTargets), ...pays.map(p => p.employeeId)])];
  const perEmployee = employees.map(id => {
    const today = sum(todays.filter(p => p.employeeId === id)), target = i.dailyTargets[id] ?? 0;
    return { employeeId: id, collectedToday: today, collectedMonth: sum(month.filter(p => p.employeeId === id)), dailyTarget: target, targetPercent: pct(today, target) };
  }).sort((a, b) => b.collectedMonth - a.collectedMonth || a.employeeId.localeCompare(b.employeeId));
  const active = custs.filter(c => c.status === 'active');
  return {
    collectedToday: sum(todays), collectedWeek: sum(inRange(pays, startOfWeek(i.today), i.today)), collectedMonth: sum(month),
    range: { from, to, total: sum(range), count: range.length, byMethod: methods },
    outstandingTotal: active.reduce((s, c) => s + c.outstanding, 0), overdueTotal: active.reduce((s, c) => s + c.overdueAmount, 0),
    uncollectedScheduledNow: active.reduce((s, c) => s + c.dueTodayAmount + c.overdueAmount, 0),
    activeCustomers: active.length, customersDueToday: active.filter(c => c.dueTodayAmount > 0).length,
    overdueCustomers: active.filter(c => c.overdueAmount > 0).length, fullyPaidAccounts: custs.filter(c => c.status === 'completed').length,
    ranking: perEmployee,
  };
}

export type Flag = 'large_amount' | 'late_sync' | 'future_dated' | 'possible_duplicate';
export function unusualPayments(payments: PaymentRecord[], opts: { largeAmount?: number; lateSyncHours?: number; futureMinutes?: number; duplicateWindowMinutes?: number } = {}) {
  const large = opts.largeAmount ?? 5_000_000, lateH = opts.lateSyncHours ?? 48, futM = opts.futureMinutes ?? 5, dupM = opts.duplicateWindowMinutes ?? 10;
  const sorted = [...payments].sort((a, b) => Date.parse(a.paidAt) - Date.parse(b.paidAt) || a.id.localeCompare(b.id));
  const out: { paymentId: string; reasons: Flag[] }[] = [];
  sorted.forEach((p, idx) => {
    const reasons: Flag[] = []; const paid = Date.parse(p.paidAt), synced = Date.parse(p.syncedAt);
    if (p.amount >= large) reasons.push('large_amount');
    if (p.recordedOffline && synced - paid > lateH * 3600_000) reasons.push('late_sync');
    if (paid - synced > futM * 60_000) reasons.push('future_dated');
    if (sorted.slice(0, idx).some(q => q.customerId === p.customerId && q.amount === p.amount && paid - Date.parse(q.paidAt) <= dupM * 60_000)) reasons.push('possible_duplicate');
    if (reasons.length) out.push({ paymentId: p.id, reasons });
  });
  return out;
}
