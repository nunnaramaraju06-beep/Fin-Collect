import type { AuditEntry, CustomerRef, Installment, PaymentRecord, Reversal } from './types.ts';

/** Everything the payment service needs inside ONE database transaction. Production = PostgreSQL (SELECT ... FOR UPDATE on customer + installments). */
export interface Tx {
  getCustomer(businessId: string, customerId: string): Promise<CustomerRef | null>;
  listInstallments(businessId: string, customerId: string): Promise<Installment[]>;
  saveInstallments(businessId: string, list: Installment[]): Promise<void>;
  setCustomerCredit(businessId: string, customerId: string, credit: number): Promise<void>;
  findPaymentByDeviceTxn(businessId: string, key: string): Promise<PaymentRecord | null>;
  findPaymentByReceiptNo(businessId: string, receiptNo: string): Promise<PaymentRecord | null>;
  findPayment(businessId: string, paymentId: string): Promise<PaymentRecord | null>;
  listCustomerPayments(businessId: string, customerId: string): Promise<PaymentRecord[]>;
  insertPayment(p: PaymentRecord): Promise<void>;
  getReversal(businessId: string, paymentId: string): Promise<Reversal | null>;
  insertReversal(r: Reversal): Promise<void>;
  audit(e: AuditEntry): Promise<void>;
}
export interface Repo { transaction<T>(fn: (tx: Tx) => Promise<T>): Promise<T> }

/** In-memory repo for tests: serialises transactions (like row locks) and rolls back on error. */
interface State {
  customers: Map<string, CustomerRef>; installments: Map<string, Installment[]>;
  payments: Map<string, PaymentRecord>; reversals: Map<string, Reversal>; audits: AuditEntry[];
}
export class InMemoryRepo implements Repo {
  state: State = { customers: new Map(), installments: new Map(), payments: new Map(), reversals: new Map(), audits: [] };
  failNextAudit = false;
  private chain: Promise<unknown> = Promise.resolve();

  async transaction<T>(fn: (tx: Tx) => Promise<T>): Promise<T> {
    const run = async () => {
      const snapshot = structuredClone(this.state);
      try { return await fn(this.makeTx()); }
      catch (e) { this.state = snapshot; throw e; }
    };
    const result = this.chain.then(run, run);
    this.chain = result.catch(() => undefined);
    return result;
  }
  private makeTx(): Tx {
    const s = () => this.state;
    const k = (b: string, id: string) => `${b}:${id}`;
    return {
      getCustomer: async (b, id) => structuredClone(s().customers.get(k(b, id)) ?? null),
      listInstallments: async (b, id) => structuredClone(s().installments.get(k(b, id)) ?? []),
      saveInstallments: async (b, list) => {
        for (const i of list) {
          const arr = s().installments.get(k(b, i.customerId)) ?? [];
          const idx = arr.findIndex(x => x.id === i.id);
          if (idx < 0) throw new Error('installment not found');
          if (i.allocatedAmount < 0 || i.allocatedAmount > i.scheduledAmount) throw new Error('DB constraint: allocated within [0, scheduled]');
          arr[idx] = structuredClone(i);
        }
      },
      setCustomerCredit: async (b, id, credit) => { const c = s().customers.get(k(b, id)); if (!c) throw new Error('no customer'); if (credit < 0) throw new Error('DB constraint: credit >= 0'); c.creditBalance = credit; },
      findPaymentByDeviceTxn: async (b, key) => structuredClone([...s().payments.values()].find(p => p.businessId === b && p.deviceTransactionId === key) ?? null),
      findPaymentByReceiptNo: async (b, r) => structuredClone([...s().payments.values()].find(p => p.businessId === b && p.receiptNo === r) ?? null),
      findPayment: async (b, id) => structuredClone(s().payments.get(k(b, id)) ?? null),
      listCustomerPayments: async (b, c) => structuredClone([...s().payments.values()].filter(p => p.businessId === b && p.customerId === c)),
      insertPayment: async p => {
        const key = k(p.businessId, p.id);
        if (s().payments.has(key)) throw new Error('DB constraint: duplicate payment id');
        if ([...s().payments.values()].some(x => x.businessId === p.businessId && (x.deviceTransactionId === p.deviceTransactionId || x.receiptNo === p.receiptNo))) throw new Error('DB unique violation');
        s().payments.set(key, structuredClone(p));
      },
      getReversal: async (b, id) => structuredClone([...s().reversals.values()].find(r => r.businessId === b && r.paymentId === id) ?? null),
      insertReversal: async r => { s().reversals.set(k(r.businessId, r.id), structuredClone(r)); },
      audit: async e => { if (this.failNextAudit) { this.failNextAudit = false; throw new Error('simulated failure'); } s().audits.push(structuredClone(e)); },
    };
  }
  // test helpers
  seedCustomer(c: CustomerRef, installments: Installment[]) {
    this.state.customers.set(`${c.businessId}:${c.id}`, structuredClone(c));
    this.state.installments.set(`${c.businessId}:${c.id}`, structuredClone(installments));
  }
}
