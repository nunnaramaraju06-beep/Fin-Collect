import { assertCentavos } from './money.ts';
import { ValidationError } from './errors.ts';

export interface ReconciliationInput {
  openingCash: number; cashCollections: number; cashExpenses: number; cashRefunds: number;
  handedOver: number; actualOnHand: number;   // employee enters both at end of shift
}
/**
 * expected on hand = opening + cash collections - authorised cash expenses - cash refunds - cash handed over
 * difference = actual on hand - expected on hand (negative = shortage, positive = excess)
 * Non-cash collections are NOT part of this calculation.
 */
export function reconcileCash(i: ReconciliationInput) {
  for (const [k, v] of Object.entries(i)) { assertCentavos(v, k); if (v < 0) throw new ValidationError(`${k} cannot be negative`); }
  const expectedOnHand = i.openingCash + i.cashCollections - i.cashExpenses - i.cashRefunds - i.handedOver;
  const difference = i.actualOnHand - expectedOnHand;
  return { expectedOnHand, difference, status: difference === 0 ? 'balanced' as const : difference < 0 ? 'shortage' as const : 'excess' as const };
}
