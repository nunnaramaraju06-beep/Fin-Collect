import { ValidationError } from './errors.ts';
import { assertCentavos } from './money.ts';
import { addDays, addMonths, isSunday, isValidDateStr } from './dates.ts';

export type Frequency = 'daily' | 'weekly' | 'biweekly' | 'monthly' | 'custom';
export interface ScheduleInput {
  frequency: Frequency;
  firstDueDate: string;
  totalAmount: number;            // total scheduled amount, centavos (agreed contract total)
  installmentAmount?: number;     // fixed installment; count is derived, last one is adjusted
  installmentCount?: number;      // alternative: fixed count; amount is derived, last one is adjusted
  customDueDates?: string[];      // required when frequency = 'custom'
  skipSundays?: boolean;          // daily only
}
export interface PlannedInstallment { sequence: number; dueDate: string; amount: number }

export function generateSchedule(inp: ScheduleInput): PlannedInstallment[] {
  assertCentavos(inp.totalAmount, 'totalAmount');
  if (inp.totalAmount <= 0) throw new ValidationError('totalAmount must be greater than zero');
  if (!isValidDateStr(inp.firstDueDate)) throw new ValidationError('firstDueDate is invalid');

  let dates: string[];
  let count: number;
  if (inp.frequency === 'custom') {
    dates = [...(inp.customDueDates ?? [])];
    if (dates.length === 0) throw new ValidationError('customDueDates required for custom schedule');
    if (!dates.every(isValidDateStr)) throw new ValidationError('customDueDates contains an invalid date');
    if (dates.some((d, i) => i > 0 && d <= dates[i - 1])) throw new ValidationError('customDueDates must be strictly increasing');
    count = dates.length;
  } else {
    if ((inp.installmentAmount === undefined) === (inp.installmentCount === undefined)) {
      throw new ValidationError('Provide exactly one of installmentAmount or installmentCount');
    }
    if (inp.installmentAmount !== undefined) {
      assertCentavos(inp.installmentAmount, 'installmentAmount');
      if (inp.installmentAmount <= 0) throw new ValidationError('installmentAmount must be greater than zero');
      count = Math.ceil(inp.totalAmount / inp.installmentAmount);
    } else {
      if (!Number.isInteger(inp.installmentCount) || inp.installmentCount! < 1) throw new ValidationError('installmentCount must be a positive integer');
      count = inp.installmentCount!;
    }
    if (count > 3660) throw new ValidationError('Schedule too long (max 3660 installments)');
    dates = datesFor(inp, count);
  }

  const base = inp.installmentAmount ?? Math.floor(inp.totalAmount / count);
  if (base <= 0) throw new ValidationError('installment amount would be zero');
  const out: PlannedInstallment[] = [];
  let used = 0;
  for (let i = 0; i < count; i++) {
    const amount = i === count - 1 ? inp.totalAmount - used : base;
    if (amount <= 0) throw new ValidationError('Schedule produced a non-positive installment');
    out.push({ sequence: i + 1, dueDate: dates[i], amount });
    used += amount;
  }
  return out;
}

function datesFor(inp: ScheduleInput, count: number): string[] {
  const out: string[] = [];
  let cursor = inp.firstDueDate;
  for (let i = 0; i < count; i++) {
    switch (inp.frequency) {
      case 'daily':
        if (inp.skipSundays) while (isSunday(cursor)) cursor = addDays(cursor, 1);
        out.push(cursor); cursor = addDays(cursor, 1); break;
      case 'weekly': out.push(addDays(inp.firstDueDate, 7 * i)); break;
      case 'biweekly': out.push(addDays(inp.firstDueDate, 14 * i)); break;
      case 'monthly': out.push(addMonths(inp.firstDueDate, i)); break;
      default: throw new ValidationError('Unsupported frequency');
    }
  }
  return out;
}

/** Summary shown to the employer BEFORE activating an account. No hidden fees, no compounding. */
export function describeSchedule(plan: PlannedInstallment[]) {
  const total = plan.reduce((s, p) => s + p.amount, 0);
  return {
    installmentCount: plan.length,
    regularInstallment: plan[0].amount,
    finalInstallment: plan[plan.length - 1].amount,
    firstDueDate: plan[0].dueDate,
    lastDueDate: plan[plan.length - 1].dueDate,
    totalScheduled: total,
    additionalFees: 0,
    note: 'Total equals the agreed contract amount. No fees or interest are added by the system.',
  };
}
