import { businessDate } from './dates.ts';
import type { PaymentRecord } from './types.ts';

export interface ExpenseRecord { id: string; employeeId: string; amount: number; method: 'cash' | 'other'; status: 'pending' | 'approved' | 'rejected'; incurredAt: string }

/** Figures that feed reconcileCash(): only the employee's own, non-reversed payments of that business date; only APPROVED cash expenses. */
export function shiftCashFigures(a: { date: string; employeeId: string; payments: PaymentRecord[]; reversedIds: Set<string>; expenses: ExpenseRecord[] }) {
  const mine = a.payments.filter(p => p.employeeId === a.employeeId && !a.reversedIds.has(p.id) && businessDate(new Date(p.paidAt)) === a.date);
  return {
    cashCollections: mine.filter(p => p.method === 'cash').reduce((s, p) => s + p.amount, 0),
    nonCashCollections: mine.filter(p => p.method !== 'cash').reduce((s, p) => s + p.amount, 0),
    cashExpenses: a.expenses.filter(e => e.employeeId === a.employeeId && e.method === 'cash' && e.status === 'approved' && businessDate(new Date(e.incurredAt)) === a.date)
      .reduce((s, e) => s + e.amount, 0),
  };
}
