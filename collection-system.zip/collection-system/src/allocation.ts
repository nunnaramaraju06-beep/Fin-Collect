import { assertCentavos } from './money.ts';
import { ValidationError } from './errors.ts';
import { outstanding } from './installments.ts';
import type { Allocation, Installment } from './types.ts';

export interface AllocationResult { allocations: Allocation[]; creditAmount: number }

/**
 * Default policy: oldest due date first. Money beyond what is due today goes to future installments
 * as 'advance' (if allowAdvance) and anything beyond the whole contract becomes customer credit.
 * Invariant: sum(allocations) + creditAmount === amount. Nothing is discarded or allocated twice.
 */
export function allocatePayment(
  amount: number, installments: Installment[], today: string,
  opts: { allowAdvance?: boolean } = {},
): AllocationResult {
  assertCentavos(amount);
  if (amount <= 0) throw new ValidationError('Payment amount must be greater than zero');
  const allowAdvance = opts.allowAdvance ?? true;
  const eligible = installments
    .filter(i => i.state === 'active' && outstanding(i) > 0)
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate) || a.sequence - b.sequence);

  let remaining = amount;
  const allocations: Allocation[] = [];
  for (const inst of eligible) {
    if (remaining === 0) break;
    const isFuture = inst.dueDate > today;
    if (isFuture && !allowAdvance) break;
    const take = Math.min(remaining, outstanding(inst));
    allocations.push({ installmentId: inst.id, amount: take, kind: isFuture ? 'advance' : 'due' });
    remaining -= take;
  }
  return { allocations, creditAmount: remaining };
}
