import { ConflictError, NotFoundError, ValidationError } from './errors.ts';

export interface RouteCandidate {
  customerId: string; name: string; lat: number | null; lng: number | null;
  priority: number;                 // higher = more important (employer-set)
  dueTodayAmount: number; overdueAmount: number; daysPastDue: number;   // centavos / days
}
export type Tier = 'due_today' | 'overdue' | 'other';
export interface RouteItem { customerId: string; position: number; tier: Tier; highlightOverdue: boolean; amountDue: number }
export interface Point { lat: number; lng: number }

export function haversineKm(a: Point, b: Point): number {
  const R = 6371, rad = (d: number) => (d * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
}
const tierOf = (c: RouteCandidate): Tier => (c.dueTodayAmount > 0 ? 'due_today' : c.overdueAmount > 0 ? 'overdue' : 'other');
const hasPoint = (c: RouteCandidate): boolean => c.lat != null && c.lng != null;
const baseOrder = (a: RouteCandidate, b: RouteCandidate) =>
  b.priority - a.priority || b.daysPastDue - a.daysPastDue || a.name.localeCompare(b.name) || a.customerId.localeCompare(b.customerId);

/** Nearest-neighbour ordering. Customers without coordinates go last, in the base order. */
function nearest(list: RouteCandidate[], from: Point | null): { ordered: RouteCandidate[]; end: Point | null } {
  const withPt = [...list].sort(baseOrder).filter(hasPoint), without = [...list].sort(baseOrder).filter(c => !hasPoint(c));
  const ordered: RouteCandidate[] = []; let cursor = from;
  while (withPt.length) {
    let bestIdx = 0;
    if (cursor) { let best = Infinity; withPt.forEach((c, i) => { const d = haversineKm(cursor!, { lat: c.lat!, lng: c.lng! }); if (d < best) { best = d; bestIdx = i; } }); }
    const [next] = withPt.splice(bestIdx, 1); ordered.push(next); cursor = { lat: next.lat!, lng: next.lng! };
  }
  return { ordered: [...ordered, ...without], end: cursor };
}

/**
 * Daily route: due-today customers first, then overdue (highlighted). Inside a tier: by priority, then days past due ('priority' mode),
 * or by walking distance ('nearest' mode). `manualOrder` (employer override) is placed first, in the given order.
 * Customers with nothing due are left out unless includeAll is set.
 */
export function buildRoute(cands: RouteCandidate[], opts: { mode?: 'priority' | 'nearest'; start?: Point | null; manualOrder?: string[]; includeAll?: boolean } = {}): RouteItem[] {
  const seen = new Set<string>();
  const eligible = cands.filter(c => (opts.includeAll || c.dueTodayAmount > 0 || c.overdueAmount > 0) && !seen.has(c.customerId) && seen.add(c.customerId));
  let sequence: RouteCandidate[] = []; let cursor: Point | null = opts.start ?? null;
  for (const tier of ['due_today', 'overdue', 'other'] as Tier[]) {
    const group = eligible.filter(c => tierOf(c) === tier);
    if (opts.mode === 'nearest') { const r = nearest(group, cursor); sequence.push(...r.ordered); cursor = r.end ?? cursor; }
    else sequence.push(...[...group].sort(baseOrder));
  }
  if (opts.manualOrder?.length) {
    const byId = new Map(sequence.map(c => [c.customerId, c]));
    const first = [...new Set(opts.manualOrder)].filter(id => byId.has(id)).map(id => byId.get(id)!);
    const firstIds = new Set(first.map(c => c.customerId));
    sequence = [...first, ...sequence.filter(c => !firstIds.has(c.customerId))];
  }
  return sequence.map((c, i) => ({ customerId: c.customerId, position: i + 1, tier: tierOf(c), highlightOverdue: c.overdueAmount > 0, amountDue: c.dueTodayAmount + c.overdueAmount }));
}

export type StopStatus = 'pending' | 'visited' | 'skipped';
export interface RouteStop { customerId: string; position: number; status: StopStatus; skipReason: string | null; doneAt: string | null }
export const toStops = (items: RouteItem[]): RouteStop[] => items.map(i => ({ customerId: i.customerId, position: i.position, status: 'pending' as StopStatus, skipReason: null, doneAt: null }));

export function nextStop(stops: RouteStop[]): RouteStop | null {
  return [...stops].filter(s => s.status === 'pending').sort((a, b) => a.position - b.position)[0] ?? null;
}
function change(stops: RouteStop[], customerId: string, fn: (s: RouteStop) => RouteStop): RouteStop[] {
  const s = stops.find(x => x.customerId === customerId);
  if (!s) throw new NotFoundError('That customer is not on today’s route');
  if (s.status !== 'pending') throw new ConflictError('That stop is already completed');
  return stops.map(x => (x === s ? fn(x) : x));
}
export const markVisited = (stops: RouteStop[], customerId: string, at: string) => change(stops, customerId, s => ({ ...s, status: 'visited' as StopStatus, doneAt: at }));
export function skipStop(stops: RouteStop[], customerId: string, reason: string, at: string) {
  if (!reason || reason.trim().length < 3) throw new ValidationError('A reason is required to skip a customer');
  return change(stops, customerId, s => ({ ...s, status: 'skipped' as StopStatus, skipReason: reason.trim(), doneAt: at }));
}
export function routeProgress(stops: RouteStop[]) {
  const visited = stops.filter(s => s.status === 'visited').length, skipped = stops.filter(s => s.status === 'skipped').length;
  const pending = stops.length - visited - skipped;
  return { total: stops.length, visited, skipped, pending, percent: stops.length ? Math.round(((visited + skipped) / stops.length) * 100) : 0,
    complete: stops.length > 0 && pending === 0, nextCustomerId: nextStop(stops)?.customerId ?? null };
}
export function completionReport(stops: RouteStop[], collectedByCustomer: Record<string, number>) {
  return { ...routeProgress(stops),
    skippedStops: stops.filter(s => s.status === 'skipped').map(s => ({ customerId: s.customerId, reason: s.skipReason })),
    totalCollected: stops.reduce((sum, s) => sum + (collectedByCustomer[s.customerId] ?? 0), 0) };
}
