export class AppError extends Error {
  code: string;
  constructor(code: string, message: string) { super(message); this.code = code; this.name = new.target.name; }
}
export class ValidationError extends AppError { constructor(m: string) { super('VALIDATION', m); } }
export class ForbiddenError extends AppError { constructor(m: string) { super('FORBIDDEN', m); } }
export class ConflictError extends AppError { constructor(m: string, code = 'CONFLICT') { super(code, m); } }
export class NotFoundError extends AppError { constructor(m: string) { super('NOT_FOUND', m); } }
