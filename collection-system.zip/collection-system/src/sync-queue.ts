/** Offline queue logic. Storage is pluggable: IndexedDB (Dexie) in the PWA, in-memory in tests. */
export type OpStatus = 'pending' | 'synced' | 'rejected' | 'conflict';
export interface QueuedOp { opId: string; type: 'payment' | 'visit' | 'expense' | 'note'; payload: unknown; createdAt: string; status: OpStatus; attempts: number; lastError?: string; nextAttemptAt?: number }
export interface QueueStore { all(): Promise<QueuedOp[]>; put(op: QueuedOp): Promise<void> }
export class NetworkError extends Error {}
/** What the server decided about one operation. Throw NetworkError for timeouts / no connection / 5xx. */
export type SendResult = { kind: 'ok' } | { kind: 'duplicate' } | { kind: 'rejected'; message: string } | { kind: 'conflict'; message: string };

export class InMemoryQueueStore implements QueueStore {
  items = new Map<string, QueuedOp>();
  async all() { return [...this.items.values()].map(o => structuredClone(o)); }
  async put(op: QueuedOp) { this.items.set(op.opId, structuredClone(op)); }
}

export class SyncQueue {
  store: QueueStore; now: () => number; baseDelayMs: number; maxDelayMs: number;
  constructor(store: QueueStore, opts: { now?: () => number; baseDelayMs?: number; maxDelayMs?: number } = {}) {
    this.store = store; this.now = opts.now ?? Date.now; this.baseDelayMs = opts.baseDelayMs ?? 2000; this.maxDelayMs = opts.maxDelayMs ?? 300000;
  }
  /** Idempotent: enqueueing the same opId twice keeps the first. The opId doubles as the server idempotency key. */
  async enqueue(op: Pick<QueuedOp, 'opId' | 'type' | 'payload'>): Promise<void> {
    if ((await this.store.all()).some(o => o.opId === op.opId)) return;
    await this.store.put({ ...op, createdAt: new Date(this.now()).toISOString(), status: 'pending', attempts: 0 });
  }
  async pending(): Promise<QueuedOp[]> { return (await this.store.all()).filter(o => o.status === 'pending'); }
  async needsAttention(): Promise<QueuedOp[]> { return (await this.store.all()).filter(o => o.status === 'rejected' || o.status === 'conflict'); }

  /** Sends pending ops oldest-first. Stops at the first network failure (connection is probably down). */
  async flush(send: (op: QueuedOp) => Promise<SendResult>, opts: { force?: boolean } = {}) {
    const summary = { synced: 0, duplicates: 0, rejected: 0, conflicts: 0, networkFailed: false };
    const ops = (await this.pending()).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    for (const op of ops) {
      if (!opts.force && op.nextAttemptAt && op.nextAttemptAt > this.now()) { summary.networkFailed = true; break; }
      try {
        const r = await send(op);
        if (r.kind === 'ok' || r.kind === 'duplicate') { op.status = 'synced'; r.kind === 'ok' ? summary.synced++ : summary.duplicates++; }
        else if (r.kind === 'rejected') { op.status = 'rejected'; op.lastError = r.message; summary.rejected++; }
        else { op.status = 'conflict'; op.lastError = r.message; summary.conflicts++; }
        op.attempts++; delete op.nextAttemptAt; await this.store.put(op);
      } catch (e) {
        if (!(e instanceof NetworkError)) throw e;
        op.attempts++; op.lastError = e.message;
        op.nextAttemptAt = this.now() + Math.min(this.maxDelayMs, this.baseDelayMs * 2 ** Math.min(op.attempts, 10));
        await this.store.put(op); summary.networkFailed = true; break;
      }
    }
    return summary;
  }
}
