export const BUSINESS_TZ = 'Asia/Manila';
const fmt = new Intl.DateTimeFormat('en-CA', { timeZone: BUSINESS_TZ, year: 'numeric', month: '2-digit', day: '2-digit' });

/** Current (or given) instant expressed as an Asia/Manila calendar date 'YYYY-MM-DD'. */
export function businessDate(at: Date = new Date()): string { return fmt.format(at); }

export function isValidDateStr(s: string): boolean {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (!m) return false;
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  return d.getUTCFullYear() === +m[1] && d.getUTCMonth() === +m[2] - 1 && d.getUTCDate() === +m[3];
}
function utc(s: string): number {
  if (!isValidDateStr(s)) throw new RangeError(`Invalid date: ${s}`);
  const [y, m, d] = s.split('-').map(Number);
  return Date.UTC(y, m - 1, d);
}
function toStr(ms: number): string { return new Date(ms).toISOString().slice(0, 10); }

export function addDays(s: string, n: number): string { return toStr(utc(s) + n * 86400000); }
/** Adds calendar months keeping the original day-of-month where possible (Jan 31 + 1 month = Feb 28/29). */
export function addMonths(s: string, n: number): string {
  const [y, m, d] = s.split('-').map(Number);
  const total = (m - 1) + n;
  const ty = y + Math.floor(total / 12);
  const tm = ((total % 12) + 12) % 12;
  const last = new Date(Date.UTC(ty, tm + 1, 0)).getUTCDate();
  return toStr(Date.UTC(ty, tm, Math.min(d, last)));
}
/** Calendar days from b to a (a - b). */
export function diffDays(a: string, b: string): number { return Math.round((utc(a) - utc(b)) / 86400000); }
export function isSunday(s: string): boolean { return new Date(utc(s)).getUTCDay() === 0; }
/** Monday of the week containing the date (weeks run Monday to Sunday, Asia/Manila business dates). */
export function startOfWeek(s: string): string { const dow = new Date(utc(s)).getUTCDay(); return addDays(s, -((dow + 6) % 7)); }
export function startOfMonth(s: string): string { return `${s.slice(0, 7)}-01`; }
