import { diffDays } from './dates.ts';
import type { Installment, InstallmentStatus } from './types.ts';

export const outstanding = (i: Installment): number => i.scheduledAmount - i.allocatedAmount;

/** Calendar days between due date and today while an active installment still has a balance. */
export function daysOverdue(i: Installment, today: string): number {
  if (i.state !== 'active' || outstanding(i) <= 0) return 0;
  return Math.max(0, diffDays(today, i.dueDate));
}

/**
 * Status rules. An installment is flagged 'overdue' only once daysOverdue exceeds the grace period;
 * during grace it still shows 'due_today' (or 'partially_paid') but daysOverdue is reported honestly.
 */
export function installmentStatus(i: Installment, today: string, graceDays = 0): InstallmentStatus {
  if (i.state === 'cancelled') return 'cancelled';
  if (i.state === 'rescheduled') return 'rescheduled';
  if (outstanding(i) <= 0) return 'paid';
  if (daysOverdue(i, today) > graceDays) return 'overdue';
  if (i.allocatedAmount > 0) return 'partially_paid';
  return i.dueDate <= today ? 'due_today' : 'upcoming';
}

/** Distinct figures, never one merged "balance": scheduled, paid, outstanding contractual, overdue, due now. */
export function summarizeAccount(list: Installment[], today: string, graceDays = 0) {
  const active = list.filter(i => i.state === 'active');
  const unpaid = active.filter(i => outstanding(i) > 0).sort((a, b) => a.dueDate.localeCompare(b.dueDate) || a.sequence - b.sequence);
  const overdue = unpaid.filter(i => installmentStatus(i, today, graceDays) === 'overdue');
  const lastPay = active.map(i => i.lastPaymentDate).filter((d): d is string => !!d).sort().pop() ?? null;
  return {
    totalScheduled: active.reduce((s, i) => s + i.scheduledAmount, 0),
    totalPaid: active.reduce((s, i) => s + i.allocatedAmount, 0),
    outstandingBalance: unpaid.reduce((s, i) => s + outstanding(i), 0),
    amountDueNow: unpaid.filter(i => i.dueDate <= today).reduce((s, i) => s + outstanding(i), 0),
    overdueAmount: overdue.reduce((s, i) => s + outstanding(i), 0),
    overdueInstallments: overdue.length,
    daysPastDue: overdue.reduce((m, i) => Math.max(m, daysOverdue(i, today)), 0),
    nextDueDate: unpaid[0]?.dueDate ?? null,
    lastPaymentDate: lastPay,
  };
}
