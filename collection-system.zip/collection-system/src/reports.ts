import { businessDate } from './dates.ts';
import type { PaymentMethod, PaymentRecord } from './types.ts';

/** Collections for a business-date range. Reversed payments are excluded, so totals equal the live transaction records. */
export function summarizeCollections(payments: PaymentRecord[], reversedIds: Set<string>, from: string, to: string, employeeId?: string) {
  const live = payments.filter(p => !reversedIds.has(p.id) && (!employeeId || p.employeeId === employeeId)).filter(p => {
    const d = businessDate(new Date(p.paidAt)); return d >= from && d <= to;
  });
  const byMethod: Record<PaymentMethod, number> = { cash: 0, bank_transfer: 0, e_wallet: 0, other: 0 };
  const byEmployee: Record<string, number> = {};
  let total = 0, allocated = 0, credit = 0;
  for (const p of live) {
    total += p.amount; byMethod[p.method] += p.amount; byEmployee[p.employeeId] = (byEmployee[p.employeeId] ?? 0) + p.amount;
    allocated += p.allocations.reduce((s, a) => s + a.amount, 0); credit += p.creditAmount;
  }
  return { count: live.length, total, byMethod, byEmployee, allocated, unallocatedCredit: credit, reconciles: total === allocated + credit };
}
