import { createHmac } from 'node:crypto';
import { formatPHP } from './money.ts';
import type { PaymentRecord } from './types.ts';

/**
 * Receipt numbers are generated ON THE DEVICE (online or offline) so one payment = one receipt number,
 * and the number never changes after sync. Format: OR-<EMPLOYEE>-<DEVICE4>-<YYYYMMDD>-<SEQ4>.
 * `sequence` must come from a persistent per-device counter in IndexedDB.
 */
export function generateReceiptNo(p: { employeeCode: string; deviceCode: string; businessDate: string; sequence: number }): string {
  if (!Number.isInteger(p.sequence) || p.sequence < 1) throw new RangeError('sequence must be a positive integer');
  const emp = p.employeeCode.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  const dev = p.deviceCode.replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 4);
  return `OR-${emp}-${dev}-${p.businessDate.replace(/-/g, '')}-${String(p.sequence).padStart(4, '0')}`;
}

const ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
/** Server-side HMAC. The secret must NEVER be shipped to the frontend, so offline receipts have no code until sync. */
export function verificationCode(secret: string, p: Pick<PaymentRecord, 'businessId' | 'id' | 'receiptNo' | 'customerId' | 'amount' | 'paidAt'>): string {
  const mac = createHmac('sha256', secret).update([p.businessId, p.id, p.receiptNo, p.customerId, p.amount, p.paidAt].join('|')).digest();
  let out = '';
  for (let i = 0; i < 10; i++) out += ALPHABET[mac[i] % 32];
  return `${out.slice(0, 5)}-${out.slice(5)}`;
}

export interface ReceiptView {
  receiptNo: string; amountText: string; method: string; paidAt: string;
  allocations: { installmentId: string; amountText: string; kind: string }[];
  creditText: string | null; syncStatus: 'cloud_confirmed' | 'local_only'; notice: string | null; verificationCode: string | null;
}
/** Plain data for the UI/PDF layer. `payment === null` means provisional (not yet synced). */
export function buildReceiptView(draft: { receiptNo: string; amount: number; method: string; paidAt: string }, payment: PaymentRecord | null): ReceiptView {
  return {
    receiptNo: draft.receiptNo,
    amountText: formatPHP(draft.amount), method: draft.method, paidAt: draft.paidAt,
    allocations: (payment?.allocations ?? []).map(a => ({ installmentId: a.installmentId, amountText: formatPHP(a.amount), kind: a.kind })),
    creditText: payment && payment.creditAmount > 0 ? formatPHP(payment.creditAmount) : null,
    syncStatus: payment ? 'cloud_confirmed' : 'local_only',
    notice: payment ? null : 'LOCALLY RECORDED — not yet synchronized. Verification code and final allocation appear after sync.',
    verificationCode: payment?.verificationCode ?? null,
  };
}
