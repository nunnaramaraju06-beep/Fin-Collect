import { AppError } from './errors.ts';
import type { PaymentInput, PaymentService } from './payments.ts';
import type { QueuedOp, SendResult } from './sync-queue.ts';
import type { Actor } from './types.ts';

/** Server-side mapping of payment-service outcomes to sync results (used by the /sync API route). */
export async function processPaymentOp(service: PaymentService, actor: Actor, op: QueuedOp): Promise<SendResult> {
  try {
    const { duplicate } = await service.recordPayment(actor, op.payload as PaymentInput);
    return { kind: duplicate ? 'duplicate' : 'ok' };
  } catch (e) {
    if (e instanceof AppError) {
      if (e.code === 'CONFLICT' || e.code === 'IDEMPOTENCY_MISMATCH' || e.code === 'RECEIPT_DUPLICATE' || e.code === 'ACCOUNT_NOT_ACTIVE') return { kind: 'conflict', message: e.message };
      return { kind: 'rejected', message: e.message };
    }
    throw e; // unexpected server error -> HTTP 5xx -> client retries
  }
}
