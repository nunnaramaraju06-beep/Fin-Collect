import { randomUUID } from 'node:crypto';
import { allocatePayment } from './allocation.ts';
import { businessDate, isValidDateStr } from './dates.ts';
import { ConflictError, ForbiddenError, NotFoundError, ValidationError } from './errors.ts';
import { assertCentavos } from './money.ts';
import { verificationCode } from './receipt.ts';
import type { Repo, Tx } from './repo.ts';
import type { Actor, GeoPoint, Installment, PaymentMethod, PaymentRecord, Reversal } from './types.ts';

export interface PaymentInput {
  businessId: string; customerId: string; employeeId: string;
  amount: number; method: PaymentMethod; paidAt: string;       // ISO timestamp with offset
  deviceTransactionId: string;                                 // idempotency key, generated on the device
  receiptNo: string;                                           // generated on the device
  reference?: string | null; note?: string | null; location?: GeoPoint | null; recordedOffline: boolean;
}
const METHODS: PaymentMethod[] = ['cash', 'bank_transfer', 'e_wallet', 'other'];

export function validateLocation(loc: GeoPoint | null | undefined): GeoPoint | null {
  if (loc == null) return null; // location is optional (permission denied / unavailable)
  if (typeof loc.lat !== 'number' || typeof loc.lng !== 'number' || !Number.isFinite(loc.lat) || !Number.isFinite(loc.lng)
    || Math.abs(loc.lat) > 90 || Math.abs(loc.lng) > 180) throw new ValidationError('Invalid GPS coordinates');
  if (Number.isNaN(Date.parse(loc.capturedAt))) throw new ValidationError('Invalid GPS timestamp');
  return loc;
}

export class PaymentService {
  repo: Repo; secret: string; graceDays: number; allowAdvance: boolean; now: () => Date;
  constructor(repo: Repo, opts: { verificationSecret: string; graceDays?: number; allowAdvance?: boolean; now?: () => Date }) {
    this.repo = repo; this.secret = opts.verificationSecret; this.graceDays = opts.graceDays ?? 0;
    this.allowAdvance = opts.allowAdvance ?? true; this.now = opts.now ?? (() => new Date());
  }

  async recordPayment(actor: Actor, input: PaymentInput): Promise<{ payment: PaymentRecord; duplicate: boolean }> {
    if (actor.businessId !== input.businessId) throw new ForbiddenError('Wrong business');
    if (actor.role === 'accountant') throw new ForbiddenError('Read-only role cannot record payments');
    if (actor.role === 'employee' && (!actor.employeeId || actor.employeeId !== input.employeeId)) throw new ForbiddenError('Employees can only record their own collections');
    this.validate(input);
    const location = validateLocation(input.location);

    return this.repo.transaction(async tx => {
      const existing = await tx.findPaymentByDeviceTxn(input.businessId, input.deviceTransactionId);
      if (existing) {
        const same = existing.customerId === input.customerId && existing.amount === input.amount && existing.method === input.method
          && existing.employeeId === input.employeeId && existing.receiptNo === input.receiptNo;
        if (!same) throw new ConflictError('Transaction ID already used for a different payment', 'IDEMPOTENCY_MISMATCH');
        return { payment: existing, duplicate: true };
      }
      if (await tx.findPaymentByReceiptNo(input.businessId, input.receiptNo)) throw new ConflictError('Receipt number already issued', 'RECEIPT_DUPLICATE');

      const customer = await tx.getCustomer(input.businessId, input.customerId);
      if (!customer) throw new NotFoundError('Customer not found');
      if (actor.role === 'employee' && customer.assignedEmployeeId !== actor.employeeId) throw new ForbiddenError('Customer is not assigned to you');
      if (customer.status !== 'active') throw new ConflictError('Customer account is not active', 'ACCOUNT_NOT_ACTIVE');

      const installments = await tx.listInstallments(input.businessId, input.customerId);
      const payDate = businessDate(new Date(input.paidAt));
      const { allocations, creditAmount } = allocatePayment(input.amount, installments, payDate, { allowAdvance: this.allowAdvance });

      const byId = new Map(installments.map(i => [i.id, i]));
      const changed: Installment[] = allocations.map(a => {
        const i = byId.get(a.installmentId)!;
        return { ...i, allocatedAmount: i.allocatedAmount + a.amount, lastPaymentDate: payDate };
      });
      await tx.saveInstallments(input.businessId, changed);
      if (creditAmount > 0) await tx.setCustomerCredit(input.businessId, input.customerId, customer.creditBalance + creditAmount);

      const base = {
        id: randomUUID(), businessId: input.businessId, customerId: input.customerId, employeeId: input.employeeId,
        amount: input.amount, method: input.method, paidAt: input.paidAt, deviceTransactionId: input.deviceTransactionId,
        receiptNo: input.receiptNo, reference: input.reference ?? null, note: input.note ?? null, location,
        recordedOffline: input.recordedOffline, syncedAt: this.now().toISOString(), allocations, creditAmount,
      };
      const payment: PaymentRecord = { ...base, verificationCode: verificationCode(this.secret, base) };
      await tx.insertPayment(payment);
      await tx.audit({ businessId: input.businessId, actorUserId: actor.userId, action: 'payment.recorded', entityType: 'payment', entityId: payment.id,
        detail: { amount: payment.amount, receiptNo: payment.receiptNo, offline: payment.recordedOffline }, at: payment.syncedAt });
      return { payment, duplicate: false };
    });
  }

  /** Controlled reversal (employer only). The original payment row is never edited or deleted. */
  async reversePayment(actor: Actor, args: { businessId: string; paymentId: string; reason: string }): Promise<Reversal> {
    if (actor.businessId !== args.businessId) throw new ForbiddenError('Wrong business');
    if (actor.role !== 'employer') throw new ForbiddenError('Only the employer can reverse payments');
    if (!args.reason || args.reason.trim().length < 5) throw new ValidationError('A reason of at least 5 characters is required');

    return this.repo.transaction(async tx => {
      const pay = await tx.findPayment(args.businessId, args.paymentId);
      if (!pay) throw new NotFoundError('Payment not found');
      if (await tx.getReversal(args.businessId, pay.id)) throw new ConflictError('Payment already reversed', 'ALREADY_REVERSED');
      const customer = await tx.getCustomer(args.businessId, pay.customerId);
      if (!customer) throw new NotFoundError('Customer not found');
      if (customer.creditBalance < pay.creditAmount) throw new ConflictError('Credit from this payment was already used; adjust manually', 'CREDIT_USED');

      const installments = await tx.listInstallments(args.businessId, pay.customerId);
      const reverseBy = new Map(pay.allocations.map(a => [a.installmentId, a.amount]));
      const reversed: Reversal = { id: randomUUID(), businessId: args.businessId, paymentId: pay.id, reason: args.reason.trim(), reversedBy: actor.userId, reversedAt: this.now().toISOString() };
      await tx.insertReversal(reversed);

      // recompute last payment date from the remaining (non-reversed) payments
      const others = (await tx.listCustomerPayments(args.businessId, pay.customerId)).filter(p => p.id !== pay.id);
      const live: PaymentRecord[] = [];
      for (const p of others) if (!(await tx.getReversal(args.businessId, p.id))) live.push(p);
      const updated = installments.filter(i => reverseBy.has(i.id)).map(i => {
        const dates = live.filter(p => p.allocations.some(a => a.installmentId === i.id)).map(p => businessDate(new Date(p.paidAt))).sort();
        return { ...i, allocatedAmount: i.allocatedAmount - reverseBy.get(i.id)!, lastPaymentDate: dates.pop() ?? null };
      });
      await tx.saveInstallments(args.businessId, updated);
      if (pay.creditAmount > 0) await tx.setCustomerCredit(args.businessId, pay.customerId, customer.creditBalance - pay.creditAmount);
      await tx.audit({ businessId: args.businessId, actorUserId: actor.userId, action: 'payment.reversed', entityType: 'payment', entityId: pay.id, detail: { reason: reversed.reason, amount: pay.amount }, at: reversed.reversedAt });
      return reversed;
    });
  }

  private validate(i: PaymentInput) {
    assertCentavos(i.amount);
    if (i.amount <= 0) throw new ValidationError('Amount must be greater than zero');
    if (!METHODS.includes(i.method)) throw new ValidationError('Unsupported payment method');
    if (!i.deviceTransactionId || i.deviceTransactionId.length > 100) throw new ValidationError('deviceTransactionId required (max 100 chars)');
    if (!i.receiptNo || i.receiptNo.length > 60) throw new ValidationError('receiptNo required (max 60 chars)');
    const t = Date.parse(i.paidAt);
    if (Number.isNaN(t) || !/[zZ]|[+-]\d{2}:\d{2}$/.test(i.paidAt)) throw new ValidationError('paidAt must be an ISO timestamp with timezone');
    if (t > this.now().getTime() + 24 * 3600 * 1000) throw new ValidationError('paidAt is too far in the future (check the phone clock)');
    if (!isValidDateStr(businessDate(new Date(t)))) throw new ValidationError('paidAt invalid');
    if ((i.reference ?? '').length > 100 || (i.note ?? '').length > 500) throw new ValidationError('Reference/note too long');
  }
}
export type { Tx };
