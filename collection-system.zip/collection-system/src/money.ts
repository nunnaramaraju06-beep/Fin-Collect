import { ValidationError } from './errors.ts';

export function assertCentavos(n: unknown, label = 'amount'): asserts n is number {
  if (typeof n !== 'number' || !Number.isSafeInteger(n)) {
    throw new ValidationError(`${label} must be a whole number of centavos`);
  }
}

/** Strict parser: "1,250.50", "₱1250", "1250.5". Rejects more than 2 decimals. */
export function pesosToCentavos(input: string): number {
  const s = input.trim().replace(/^₱\s*/, '').replace(/,/g, '');
  const m = /^(-?)(\d+)(?:\.(\d{1,2}))?$/.exec(s);
  if (!m) throw new ValidationError(`Invalid peso amount: "${input}"`);
  const cents = Number(m[2]) * 100 + Number((m[3] ?? '').padEnd(2, '0') || '0');
  assertCentavos(cents);
  return m[1] === '-' ? -cents : cents;
}

export function formatPHP(centavos: number): string {
  assertCentavos(centavos);
  const abs = Math.abs(centavos);
  const whole = Math.trunc(abs / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return `${centavos < 0 ? '-' : ''}₱${whole}.${String(abs % 100).padStart(2, '0')}`;
}
