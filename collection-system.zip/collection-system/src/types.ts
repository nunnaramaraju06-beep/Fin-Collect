export type Role = 'employer' | 'employee' | 'accountant';
export interface Actor { userId: string; businessId: string; role: Role; employeeId?: string }
export type PaymentMethod = 'cash' | 'bank_transfer' | 'e_wallet' | 'other';
export type InstallmentState = 'active' | 'rescheduled' | 'cancelled';
export type InstallmentStatus = 'upcoming' | 'due_today' | 'partially_paid' | 'paid' | 'overdue' | 'rescheduled' | 'cancelled';
/** All money is integer centavos. Dates are 'YYYY-MM-DD' business dates (Asia/Manila). */
export interface Installment {
  id: string; customerId: string; sequence: number; dueDate: string;
  scheduledAmount: number; allocatedAmount: number;
  lastPaymentDate: string | null; state: InstallmentState;
}
export interface Allocation { installmentId: string; amount: number; kind: 'due' | 'advance' }
export interface GeoPoint { lat: number; lng: number; accuracyM?: number; capturedAt: string }
export interface PaymentRecord {
  id: string; businessId: string; customerId: string; employeeId: string;
  amount: number; method: PaymentMethod; paidAt: string;
  deviceTransactionId: string; receiptNo: string; verificationCode: string;
  reference: string | null; note: string | null; location: GeoPoint | null;
  recordedOffline: boolean; syncedAt: string; allocations: Allocation[]; creditAmount: number;
}
export interface Reversal { id: string; businessId: string; paymentId: string; reason: string; reversedBy: string; reversedAt: string }
export interface CustomerRef {
  id: string; businessId: string; assignedEmployeeId: string | null;
  status: 'prospect' | 'active' | 'completed' | 'inactive' | 'disputed'; creditBalance: number;
}
export interface AuditEntry {
  businessId: string; actorUserId: string; action: string; entityType: string;
  entityId: string; detail: Record<string, unknown>; at: string;
}
