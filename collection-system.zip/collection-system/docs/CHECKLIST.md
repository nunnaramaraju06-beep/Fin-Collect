# Status checklist (honest)

Legend: ✅ done and tested by executing code · 📝 written, not executed · ❌ not started · 🔑 needs API key/account · 💰 may need paid plan

## Results actually executed
`npm test` → 48 tests, 48 passed, 0 failed (Node v22.22.2). Type-check of `src/` passed using a stub for Node's crypto typing, because `@types/node` could not be installed offline. Run `npm i -D typescript @types/node && npm run typecheck` on your machine for the full check.

## Business logic
- ✅ Integer-centavo money, PHP formatting, Asia/Manila business date
- ✅ Daily/weekly/biweekly/monthly/custom schedules, final adjusted installment, skip-Sundays option
- ✅ Days overdue, statuses, grace period, account summary with separate figures
- ✅ Allocation: partial, multiple installments, advance, overpayment → credit
- ✅ Idempotent payments; duplicate/parallel/two-device protection; receipt-number uniqueness
- ✅ Atomic rollback on failure; reversal with reason/user/time; original preserved
- ✅ Role/ownership checks in the service (employee vs other employee, auditor read-only, other business)
- ✅ Offline queue: retry/backoff, response-lost retry, conflicts/rejections surfaced
- ✅ Cash reconciliation formula; report totals reconcile to transactions
- ✅ GPS validation (optional location accepted, invalid coordinates rejected)
- ❌ Refund records, adjustments, rescheduling approval flow, early settlement, account closure
- ❌ Applying customer credit to later installments; remaining-principal accounting

## Database
- 📝 Full schema, constraints, immutability triggers, RLS (never executed — run it and report errors)
- ❌ Migration runner, seed of clearly-labelled demo data, PostgreSQL `Repo` implementation
- ❌ Automated tests for persistence after restart/redeploy, backup and restore

## Application layers (all ❌ — not started)
Authentication (setup secret, email verification, login rate limits, password reset, suspension/session revoke) · API · employee PWA · employer dashboard · routes and maps · notifications · exports (CSV/Excel) · PDF/printable receipts · offline storage in IndexedDB · privacy notice screens · deployment config · Android install test.

## Services
- OpenStreetMap + Leaflet: free, no key.
- Email (verification/reset): 🔑 needs an SMTP/email provider; may be 💰 beyond a free quota.
- SMS reminders: 🔑💰 optional; carriers/providers charge per message.
- PostgreSQL hosting: 💰 recommended paid tier for daily backups; free tiers exist with limits — verify current terms.
- Google Maps: 🔑💰 not needed; OpenStreetMap is the recommended alternative.

## Not verified anywhere yet
Behaviour on real Android phones (IndexedDB eviction, install, share, GPS), HTTPS deployment, real PostgreSQL concurrency (the in-memory repo only simulates row locks), RLS policies.

## Added after the first package
- ✅ Daily route building (due-today first, overdue highlighted, priority, nearest-next, employer manual override), stop progress, skip-with-reason, completion report: tested
- ✅ Employee and employer dashboard calculations, filters, ranking, targets, unusual-payment flags: tested
- ✅ Shift cash figures feeding the reconciliation formula: tested
- 📝 `api/` (Fastify + zod + pg + argon2id) and `db/migrations/002_auth_and_fixes.sql`: written, type-checked against stand-in type stubs only, **never started or connected to PostgreSQL, no automated tests**. See `docs/API_SETUP.md`.
- ❌ No endpoints yet for dashboards, routes, expenses, visits, cash reconciliation, notifications, exports, receipts PDF.
- ❌ Frontend (PWA), IndexedDB storage, maps screens, deployment: not built.
