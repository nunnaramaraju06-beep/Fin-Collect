# API setup (Phase 3) — written, NOT yet run against a real database

Everything in `api/` type-checks against stand-in type stubs only. It has **never been started, never connected to PostgreSQL, and has no automated tests**. The core logic it calls (`../src/…`) is the part with 33 passing tests.

## 1. Database (Supabase SQL Editor, once)
Run `db/migrations/002_auth_and_fixes.sql`. It fixes the audit-log policy (employees must be able to write audit rows), adds ID sequences, and adds the secure login/setup functions. Assumes ONE business per database. Success = "No rows returned".

## 2. Connection string
Supabase → **Connect** → choose **Session pooler**. The username must be `app_user.<your-project-ref>` (not just `app_user`), and the password is the one you set for `app_user`. Put it in `DATABASE_URL`. Never use the `postgres` login or the `service_role` key.

## 3. Environment variables (host settings, never in code)
`DATABASE_URL`, `INITIAL_SETUP_SECRET` (16+ random characters), `RECEIPT_VERIFICATION_SECRET` (32+ random characters, never change it later or old receipt codes stop verifying), `NODE_ENV=production`.

## 4. Deploy (example: Render, Web Service)
Repository root = this folder. Build command: `cd api && npm install`. Start command: `cd api && npm start`. Add the environment variables. HTTPS is automatic.

## 5. First employer
Open `https://YOUR-APP/setup` on your phone, enter the setup secret and your details. It works once. Afterwards delete `INITIAL_SETUP_SECRET`.

## 6. Smoke test (in order)
1. `GET /health` returns `{"ok":true}`.
2. Sign in: `POST /api/auth/login`.
3. Employee signup → employer approves → employee signs in.
4. Create a customer, preview a schedule with `dryRun: true`, then activate it.
5. Record a payment, send the same payment again (must return `duplicate: true`), reverse it.
6. As the employee, request another employee's customer (must be "not found").
Report any failure with the exact error text.

## Endpoints
`POST /setup` · `POST /api/auth/{login,logout,signup,change-password}` · `GET /api/auth/me` · `GET /api/employees` · `POST /api/employees/:id/{approve,status}` · `GET|POST /api/customers` · `POST /api/customers/:id/{reassign,contract}` · `GET /api/customers/:id/account` · `POST /api/payments` · `POST /api/payments/:id/reverse` · `POST /api/sync` · `GET /api/reports/collections`

## Not built yet
Email verification and password recovery (need an email provider), employer password reset, expenses, visits and routes, cash reconciliation endpoint, notifications, CSV/Excel export, PDF receipts, PIN re-entry, refunds and adjustments, backups automation, frontend.

## Known risks to check
- SECURITY DEFINER functions rely on setting the business context inside the function so they work whether or not the owner role bypasses Row Level Security. Verify with the smoke tests.
- CSRF protection is `SameSite=Strict` cookies only; keep the app and API on one domain.
