-- 002: login/setup functions, code sequences, audit-log policy fix.
-- STATUS: written, NOT executed in the authoring environment. Run once in the Supabase SQL Editor after 001.
-- Assumes ONE business per database (single-business deployment).

-- Fix: employees' actions must be able to WRITE audit rows; only READING is restricted.
DROP POLICY employee_scope ON audit_logs;
CREATE POLICY audit_read_scope ON audit_logs AS RESTRICTIVE FOR SELECT USING (app_role() IN ('employer','accountant'));

CREATE SEQUENCE customer_code_seq;
CREATE SEQUENCE employee_code_seq;
GRANT USAGE ON SEQUENCE customer_code_seq, employee_code_seq TO app_user;

-- Internal helper: puts THIS transaction in the single business's employer context. Not callable by the app role.
CREATE FUNCTION app_enter() RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE b uuid;
BEGIN
  SELECT x.id INTO b FROM businesses x ORDER BY x.created_at LIMIT 1;
  IF b IS NOT NULL THEN
    PERFORM set_config('app.business_id', b::text, true);
    PERFORM set_config('app.role', 'employer', true);
    PERFORM set_config('app.user_id', '', true);
  END IF;
  RETURN b;
END $$;

CREATE FUNCTION app_login_lookup(p_email text)
RETURNS TABLE (id uuid, business_id uuid, role text, status text, password_hash text, full_name text, failed_logins integer, locked_until timestamptz, employee_code text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF app_enter() IS NULL THEN RETURN; END IF;
  RETURN QUERY
    SELECT u.id, u.business_id, u.role, u.status, u.password_hash, u.full_name, u.failed_logins, u.locked_until, e.employee_code
    FROM users u LEFT JOIN employee_profiles e ON e.user_id = u.id
    WHERE lower(u.email) = lower(p_email);
END $$;

CREATE FUNCTION app_record_login(p_user uuid, p_ok boolean) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM app_enter();
  IF p_ok THEN
    UPDATE users SET failed_logins = 0, locked_until = NULL WHERE id = p_user;
  ELSE
    UPDATE users SET failed_logins = failed_logins + 1,
      locked_until = CASE WHEN failed_logins + 1 >= 5 THEN now() + interval '15 minutes' ELSE locked_until END
    WHERE id = p_user;
  END IF;
END $$;

CREATE FUNCTION app_create_session(p_user uuid, p_hash text, p_expires timestamptz, p_ip text, p_ua text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE b uuid;
BEGIN
  b := app_enter();
  INSERT INTO sessions (user_id, business_id, token_hash, expires_at, ip, user_agent)
  VALUES (p_user, b, p_hash, p_expires, NULLIF(p_ip, '')::inet, left(p_ua, 300));
END $$;

CREATE FUNCTION app_session_lookup(p_hash text)
RETURNS TABLE (user_id uuid, business_id uuid, role text, status text, employee_code text, full_name text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF app_enter() IS NULL THEN RETURN; END IF;
  RETURN QUERY
    SELECT u.id, u.business_id, u.role, u.status, e.employee_code, u.full_name
    FROM sessions s JOIN users u ON u.id = s.user_id LEFT JOIN employee_profiles e ON e.user_id = u.id
    WHERE s.token_hash = p_hash AND s.revoked_at IS NULL AND s.expires_at > now() AND u.status = 'active';
END $$;

CREATE FUNCTION app_revoke_session(p_hash text) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM app_enter();
  UPDATE sessions SET revoked_at = now() WHERE token_hash = p_hash AND revoked_at IS NULL;
END $$;

-- One-time creation of the first employer. Fails if any business already exists.
CREATE FUNCTION app_setup_first_employer(p_business text, p_email text, p_name text, p_hash text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE b uuid; u uuid;
BEGIN
  LOCK TABLE businesses IN EXCLUSIVE MODE;
  IF EXISTS (SELECT 1 FROM businesses) THEN RAISE EXCEPTION 'already set up'; END IF;
  INSERT INTO businesses (name) VALUES (p_business) RETURNING id INTO b;
  PERFORM set_config('app.business_id', b::text, true);
  PERFORM set_config('app.role', 'employer', true);
  PERFORM set_config('app.user_id', '', true);
  INSERT INTO users (business_id, email, full_name, password_hash, role, status)
  VALUES (b, p_email, p_name, p_hash, 'employer', 'active') RETURNING id INTO u;
  INSERT INTO audit_logs (business_id, actor_user_id, action, entity_type, entity_id, detail)
  VALUES (b, u, 'setup.first_employer', 'user', u::text, '{}'::jsonb);
  RETURN u;
END $$;

-- Public employee signup request: always created as role employee, status pending.
CREATE FUNCTION app_register_employee(p_email text, p_name text, p_mobile text, p_hash text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE b uuid; u uuid;
BEGIN
  b := app_enter();
  IF b IS NULL THEN RAISE EXCEPTION 'not set up'; END IF;
  INSERT INTO users (business_id, email, full_name, mobile, password_hash, role, status)
  VALUES (b, p_email, p_name, p_mobile, p_hash, 'employee', 'pending') RETURNING id INTO u;
  INSERT INTO audit_logs (business_id, actor_user_id, action, entity_type, entity_id, detail)
  VALUES (b, u, 'employee.signup_requested', 'user', u::text, '{}'::jsonb);
  RETURN u;
END $$;

-- Only the app role may call the public-facing functions. Never anon/authenticated (Supabase public API roles).
REVOKE ALL ON FUNCTION app_enter() FROM PUBLIC;
REVOKE ALL ON FUNCTION app_login_lookup(text), app_record_login(uuid, boolean), app_create_session(uuid, text, timestamptz, text, text),
  app_session_lookup(text), app_revoke_session(text), app_setup_first_employer(text, text, text, text), app_register_employee(text, text, text, text) FROM PUBLIC;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    REVOKE ALL ON FUNCTION app_enter(), app_login_lookup(text), app_record_login(uuid, boolean), app_create_session(uuid, text, timestamptz, text, text),
      app_session_lookup(text), app_revoke_session(text), app_setup_first_employer(text, text, text, text), app_register_employee(text, text, text, text)
      FROM anon, authenticated;
    ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE EXECUTE ON FUNCTIONS FROM anon, authenticated;
  END IF;
END $$;
GRANT EXECUTE ON FUNCTION app_login_lookup(text), app_record_login(uuid, boolean), app_create_session(uuid, text, timestamptz, text, text),
  app_session_lookup(text), app_revoke_session(text), app_setup_first_employer(text, text, text, text), app_register_employee(text, text, text, text) TO app_user;
