-- Daily Collection Management System: PostgreSQL schema (v0.1)
-- STATUS: written but NOT executed in the authoring environment (no PostgreSQL available there).
-- Run it on an empty database and fix any error before use. Requires PostgreSQL 13+.
-- Money = integer centavos (bigint). Business dates are plain `date` in Asia/Manila; instants are timestamptz.

BEGIN;

CREATE TABLE businesses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL, address text, phone text, email text,
  timezone text NOT NULL DEFAULT 'Asia/Manila',
  receipt_footer text, privacy_notice text,
  retention_months integer CHECK (retention_months IS NULL OR retention_months >= 12),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id),
  email text NOT NULL, full_name text NOT NULL, mobile text,
  password_hash text,                      -- argon2id/bcrypt hash only (or NULL if an external auth provider is used)
  role text NOT NULL CHECK (role IN ('employer','employee','accountant')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','suspended','deactivated')),
  email_verified_at timestamptz, failed_logins integer NOT NULL DEFAULT 0, locked_until timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX users_email_uq ON users (lower(email));
CREATE INDEX users_business_idx ON users (business_id, role, status);

CREATE TABLE sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id), business_id uuid NOT NULL REFERENCES businesses(id),
  token_hash text NOT NULL UNIQUE,         -- store a hash of the session token, never the token
  expires_at timestamptz NOT NULL, revoked_at timestamptz, ip inet, user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX sessions_user_idx ON sessions (user_id) WHERE revoked_at IS NULL;

CREATE TABLE roles_permissions (
  role text NOT NULL CHECK (role IN ('employer','employee','accountant')),
  permission text NOT NULL, PRIMARY KEY (role, permission)
);

CREATE TABLE employee_profiles (
  user_id uuid PRIMARY KEY REFERENCES users(id),
  business_id uuid NOT NULL REFERENCES businesses(id),
  employee_code text NOT NULL, daily_target_centavos bigint NOT NULL DEFAULT 0 CHECK (daily_target_centavos >= 0),
  pin_hash text, approved_by uuid REFERENCES users(id), approved_at timestamptz,
  UNIQUE (business_id, employee_code)
);

CREATE TABLE customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id),
  customer_code text NOT NULL, full_name text NOT NULL, mobile text, alt_mobile text,
  address text, barangay text, municipality text, province text,
  latitude numeric(9,6) CHECK (latitude BETWEEN -90 AND 90), longitude numeric(9,6) CHECK (longitude BETWEEN -180 AND 180),
  location_consent_at timestamptz, photo_url text, photo_consent_at timestamptz,
  status text NOT NULL DEFAULT 'prospect' CHECK (status IN ('prospect','active','completed','inactive','disputed')),
  assigned_employee_id uuid REFERENCES users(id),     -- current assignment (history in customer_assignments)
  credit_centavos bigint NOT NULL DEFAULT 0 CHECK (credit_centavos >= 0),
  next_followup_date date, registered_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid REFERENCES users(id), approved_by uuid REFERENCES users(id), approved_at timestamptz,
  UNIQUE (business_id, customer_code),
  CHECK (photo_url IS NULL OR photo_consent_at IS NOT NULL)
);
CREATE INDEX customers_assigned_idx ON customers (business_id, assigned_employee_id, status);
CREATE INDEX customers_area_idx ON customers (business_id, municipality, barangay);

CREATE TABLE customer_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), customer_id uuid NOT NULL REFERENCES customers(id),
  employee_id uuid NOT NULL REFERENCES users(id), assigned_by uuid NOT NULL REFERENCES users(id),
  assigned_at timestamptz NOT NULL DEFAULT now(), unassigned_at timestamptz
);
CREATE UNIQUE INDEX one_active_assignment ON customer_assignments (customer_id) WHERE unassigned_at IS NULL;

CREATE TABLE customer_accounts (   -- configurable account types per business
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), name text NOT NULL,
  kind text NOT NULL CHECK (kind IN ('installment','fixed_term','recurring')), active boolean NOT NULL DEFAULT true,
  UNIQUE (business_id, name)
);

CREATE TABLE contracts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), customer_id uuid NOT NULL REFERENCES customers(id),
  account_type_id uuid REFERENCES customer_accounts(id),
  principal_centavos bigint CHECK (principal_centavos IS NULL OR principal_centavos > 0),
  total_contract_centavos bigint NOT NULL CHECK (total_contract_centavos > 0),
  frequency text NOT NULL CHECK (frequency IN ('daily','weekly','biweekly','monthly','custom')),
  installment_centavos bigint CHECK (installment_centavos IS NULL OR installment_centavos > 0),
  start_date date NOT NULL, end_date date, grace_days integer NOT NULL DEFAULT 0 CHECK (grace_days >= 0),
  allocation_policy text NOT NULL DEFAULT 'oldest_first',
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','pending_approval','active','closed','cancelled')),
  approved_by uuid REFERENCES users(id), approved_at timestamptz,
  CHECK (end_date IS NULL OR end_date >= start_date)
);
CREATE INDEX contracts_customer_idx ON contracts (business_id, customer_id);

CREATE TABLE payment_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), contract_id uuid NOT NULL REFERENCES contracts(id),
  params jsonb NOT NULL, generated_by uuid REFERENCES users(id), generated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE installments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), contract_id uuid NOT NULL REFERENCES contracts(id),
  customer_id uuid NOT NULL REFERENCES customers(id), schedule_id uuid REFERENCES payment_schedules(id),
  sequence integer NOT NULL CHECK (sequence > 0), due_date date NOT NULL,
  scheduled_centavos bigint NOT NULL CHECK (scheduled_centavos > 0),
  allocated_centavos bigint NOT NULL DEFAULT 0,
  state text NOT NULL DEFAULT 'active' CHECK (state IN ('active','rescheduled','cancelled')),
  cancel_reason text, last_payment_date date,
  UNIQUE (contract_id, sequence),
  CHECK (allocated_centavos >= 0 AND allocated_centavos <= scheduled_centavos),
  CHECK (state <> 'cancelled' OR cancel_reason IS NOT NULL)
);
CREATE INDEX installments_due_idx ON installments (business_id, customer_id, due_date) WHERE state = 'active' AND allocated_centavos < scheduled_centavos;

CREATE TABLE payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), customer_id uuid NOT NULL REFERENCES customers(id),
  employee_id uuid NOT NULL REFERENCES users(id),
  amount_centavos bigint NOT NULL CHECK (amount_centavos > 0),
  credit_centavos bigint NOT NULL DEFAULT 0 CHECK (credit_centavos >= 0),
  method text NOT NULL CHECK (method IN ('cash','bank_transfer','e_wallet','other')),
  paid_at timestamptz NOT NULL, device_id text, device_transaction_id text NOT NULL,
  receipt_no text NOT NULL, verification_code text NOT NULL, reference_no text, note text,
  latitude numeric(9,6), longitude numeric(9,6), location_accuracy_m integer, location_captured_at timestamptz,
  recorded_offline boolean NOT NULL DEFAULT false, synced_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, device_transaction_id),      -- server-side duplicate protection (idempotency key)
  UNIQUE (business_id, receipt_no)                  -- one receipt number per payment
);
CREATE INDEX payments_customer_idx ON payments (business_id, customer_id, paid_at);
CREATE INDEX payments_employee_idx ON payments (business_id, employee_id, paid_at);

CREATE TABLE payment_allocations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), payment_id uuid NOT NULL REFERENCES payments(id),
  installment_id uuid NOT NULL REFERENCES installments(id),
  amount_centavos bigint NOT NULL CHECK (amount_centavos > 0), kind text NOT NULL CHECK (kind IN ('due','advance'))
);
CREATE INDEX allocations_payment_idx ON payment_allocations (payment_id);
CREATE INDEX allocations_installment_idx ON payment_allocations (installment_id);

CREATE TABLE payment_reversals (       -- corrections are linked rows; the original payment is never edited
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), payment_id uuid NOT NULL UNIQUE REFERENCES payments(id),
  reason text NOT NULL CHECK (length(trim(reason)) >= 5), reversed_by uuid NOT NULL REFERENCES users(id),
  reversed_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE receipts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), payment_id uuid NOT NULL UNIQUE REFERENCES payments(id),
  receipt_no text NOT NULL, verification_code text NOT NULL, issued_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, receipt_no)
);

CREATE TABLE customer_visits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), customer_id uuid NOT NULL REFERENCES customers(id),
  employee_id uuid NOT NULL REFERENCES users(id), visit_date date NOT NULL,
  outcome text NOT NULL CHECK (outcome IN ('visited','failed','skipped')), reason text,
  latitude numeric(9,6), longitude numeric(9,6), visited_at timestamptz NOT NULL,
  device_transaction_id text NOT NULL, UNIQUE (business_id, device_transaction_id)
);
CREATE TABLE route_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), employee_id uuid NOT NULL REFERENCES users(id),
  route_date date NOT NULL, status text NOT NULL DEFAULT 'planned' CHECK (status IN ('planned','in_progress','completed')),
  started_at timestamptz, completed_at timestamptz, UNIQUE (employee_id, route_date)
);
CREATE TABLE route_stops (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), route_plan_id uuid NOT NULL REFERENCES route_plans(id),
  customer_id uuid NOT NULL REFERENCES customers(id), position integer NOT NULL CHECK (position > 0),
  priority integer NOT NULL DEFAULT 0, status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','visited','skipped')),
  skip_reason text, UNIQUE (route_plan_id, position), UNIQUE (route_plan_id, customer_id)
);

CREATE TABLE expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), employee_id uuid NOT NULL REFERENCES users(id),
  amount_centavos bigint NOT NULL CHECK (amount_centavos > 0), category text NOT NULL,
  method text NOT NULL DEFAULT 'cash' CHECK (method IN ('cash','other')), note text, incurred_at timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  reviewed_by uuid REFERENCES users(id), reviewed_at timestamptz,
  device_transaction_id text NOT NULL, UNIQUE (business_id, device_transaction_id)
);
CREATE TABLE cash_reconciliations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), employee_id uuid NOT NULL REFERENCES users(id),
  shift_date date NOT NULL,
  opening_centavos bigint NOT NULL CHECK (opening_centavos >= 0), cash_collected_centavos bigint NOT NULL CHECK (cash_collected_centavos >= 0),
  cash_expenses_centavos bigint NOT NULL CHECK (cash_expenses_centavos >= 0), cash_refunds_centavos bigint NOT NULL DEFAULT 0 CHECK (cash_refunds_centavos >= 0),
  handed_over_centavos bigint NOT NULL CHECK (handed_over_centavos >= 0), actual_on_hand_centavos bigint NOT NULL CHECK (actual_on_hand_centavos >= 0),
  expected_on_hand_centavos bigint NOT NULL, difference_centavos bigint NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(), UNIQUE (employee_id, shift_date),
  CHECK (expected_on_hand_centavos = opening_centavos + cash_collected_centavos - cash_expenses_centavos - cash_refunds_centavos - handed_over_centavos),
  CHECK (difference_centavos = actual_on_hand_centavos - expected_on_hand_centavos)
);
CREATE TABLE customer_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), customer_id uuid NOT NULL REFERENCES customers(id),
  author_id uuid NOT NULL REFERENCES users(id), body text NOT NULL CHECK (length(body) <= 2000), followup_date date,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), user_id uuid NOT NULL REFERENCES users(id),
  type text NOT NULL, title text NOT NULL, body text, read_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE audit_logs (
  id bigserial PRIMARY KEY, business_id uuid NOT NULL REFERENCES businesses(id), actor_user_id uuid,
  action text NOT NULL, entity_type text NOT NULL, entity_id text NOT NULL, detail jsonb NOT NULL DEFAULT '{}',
  ip inet, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_entity_idx ON audit_logs (business_id, entity_type, entity_id);
CREATE TABLE device_registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), user_id uuid NOT NULL REFERENCES users(id),
  device_code text NOT NULL, label text, last_sync_at timestamptz, revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(), UNIQUE (business_id, device_code)
);
CREATE TABLE sync_operations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id), user_id uuid NOT NULL REFERENCES users(id), device_code text,
  op_id text NOT NULL, op_type text NOT NULL, status text NOT NULL CHECK (status IN ('synced','duplicate','rejected','conflict')),
  error text, received_at timestamptz NOT NULL DEFAULT now(), UNIQUE (business_id, op_id)
);
CREATE TABLE app_settings (
  business_id uuid NOT NULL REFERENCES businesses(id), key text NOT NULL, value jsonb NOT NULL,
  PRIMARY KEY (business_id, key)
);

-- Immutability: confirmed financial records and the audit log can never be edited or deleted.
CREATE FUNCTION forbid_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION '% on % is not allowed (use a linked reversal/adjustment)', TG_OP, TG_TABLE_NAME; END $$;
CREATE TRIGGER payments_immutable BEFORE UPDATE OR DELETE ON payments FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER allocations_immutable BEFORE UPDATE OR DELETE ON payment_allocations FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER reversals_immutable BEFORE UPDATE OR DELETE ON payment_reversals FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER receipts_immutable BEFORE UPDATE OR DELETE ON receipts FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER audit_immutable BEFORE UPDATE OR DELETE ON audit_logs FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

-- Row Level Security. The API connects as a NON-owner role and runs, at the start of EVERY transaction:
--   SELECT set_config('app.business_id', '<uuid>', true), set_config('app.user_id', '<uuid>', true), set_config('app.role', 'employee', true);
-- Without these settings no rows are visible (fail closed).
CREATE FUNCTION app_business() RETURNS uuid LANGUAGE sql STABLE AS $$ SELECT nullif(current_setting('app.business_id', true), '')::uuid $$;
CREATE FUNCTION app_user() RETURNS uuid LANGUAGE sql STABLE AS $$ SELECT nullif(current_setting('app.user_id', true), '')::uuid $$;
CREATE FUNCTION app_role() RETURNS text LANGUAGE sql STABLE AS $$ SELECT nullif(current_setting('app.role', true), '') $$;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['users','sessions','employee_profiles','customers','customer_assignments','customer_accounts','contracts',
    'payment_schedules','installments','payments','payment_allocations','payment_reversals','receipts','customer_visits','route_plans',
    'route_stops','expenses','cash_reconciliations','customer_notes','notifications','audit_logs','device_registrations','sync_operations','app_settings']
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY business_isolation ON %I USING (business_id = app_business()) WITH CHECK (business_id = app_business())', t);
  END LOOP;
END $$;

-- Employees only see their own customers and their own records (RESTRICTIVE = ANDed with business_isolation).
CREATE POLICY employee_scope ON customers AS RESTRICTIVE USING (app_role() <> 'employee' OR assigned_employee_id = app_user());
CREATE POLICY employee_scope ON contracts AS RESTRICTIVE USING (app_role() <> 'employee' OR customer_id IN (SELECT id FROM customers));
CREATE POLICY employee_scope ON installments AS RESTRICTIVE USING (app_role() <> 'employee' OR customer_id IN (SELECT id FROM customers));
CREATE POLICY employee_scope ON customer_notes AS RESTRICTIVE USING (app_role() <> 'employee' OR customer_id IN (SELECT id FROM customers));
CREATE POLICY employee_scope ON payments AS RESTRICTIVE USING (app_role() <> 'employee' OR employee_id = app_user());
CREATE POLICY employee_scope ON payment_allocations AS RESTRICTIVE USING (app_role() <> 'employee' OR payment_id IN (SELECT id FROM payments));
CREATE POLICY employee_scope ON receipts AS RESTRICTIVE USING (app_role() <> 'employee' OR payment_id IN (SELECT id FROM payments));
CREATE POLICY employee_scope ON customer_visits AS RESTRICTIVE USING (app_role() <> 'employee' OR employee_id = app_user());
CREATE POLICY employee_scope ON expenses AS RESTRICTIVE USING (app_role() <> 'employee' OR employee_id = app_user());
CREATE POLICY employee_scope ON cash_reconciliations AS RESTRICTIVE USING (app_role() <> 'employee' OR employee_id = app_user());
CREATE POLICY employee_scope ON route_plans AS RESTRICTIVE USING (app_role() <> 'employee' OR employee_id = app_user());
CREATE POLICY employee_scope ON notifications AS RESTRICTIVE USING (app_role() <> 'employee' OR user_id = app_user());
CREATE POLICY employee_scope ON users AS RESTRICTIVE USING (app_role() <> 'employee' OR id = app_user());
CREATE POLICY employee_scope ON audit_logs AS RESTRICTIVE USING (app_role() IN ('employer','accountant'));
-- Auditor is read-only: block writes for the accountant role on every table that has business isolation.
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['customers','contracts','installments','payments','payment_allocations','payment_reversals','receipts','expenses','cash_reconciliations','customer_notes']
  LOOP
    EXECUTE format('CREATE POLICY accountant_read_only_ins ON %I AS RESTRICTIVE FOR INSERT WITH CHECK (app_role() <> ''accountant'')', t);
    EXECUTE format('CREATE POLICY accountant_read_only_upd ON %I AS RESTRICTIVE FOR UPDATE USING (app_role() <> ''accountant'')', t);
  END LOOP;
END $$;

-- Supabase only: stop the public Data API roles (anon/authenticated) from touching these tables at all.
-- Harmless elsewhere: the block does nothing if those roles do not exist.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon, authenticated;
    REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM anon, authenticated;
    ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON TABLES FROM anon, authenticated;
  END IF;
END $$;

-- Demonstration data is NOT seeded here. Create the first employer through the one-time setup route.
COMMIT;
