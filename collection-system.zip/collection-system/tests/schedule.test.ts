import { test } from 'node:test';
import assert from 'node:assert/strict';
import { pesosToCentavos, formatPHP } from '../src/money.ts';
import { addMonths, businessDate, diffDays } from '../src/dates.ts';
import { generateSchedule, describeSchedule } from '../src/schedule.ts';
import { daysOverdue, installmentStatus, summarizeAccount } from '../src/installments.ts';
import { makeInstallments } from './helpers.ts';

test('money: exact centavos, no floating point drift', () => {
  assert.equal(pesosToCentavos('0.10') + pesosToCentavos('0.20'), pesosToCentavos('0.30'));
  assert.equal(pesosToCentavos('₱1,250.5'), 125050);
  assert.throws(() => pesosToCentavos('10.999'));
  assert.equal(formatPHP(123456789), '₱1,234,567.89');
});

test('dates: Asia/Manila business date near midnight UTC', () => {
  assert.equal(businessDate(new Date('2026-10-22T16:30:00Z')), '2026-10-23'); // 00:30 in Manila
  assert.equal(businessDate(new Date('2026-10-22T15:30:00Z')), '2026-10-22');
  assert.equal(addMonths('2026-01-31', 1), '2026-02-28');
  assert.equal(addMonths('2028-01-31', 1), '2028-02-29');
  assert.equal(diffDays('2026-10-25', '2026-10-23'), 2);
});

test('schedule: daily, final installment adjusted, total matches contract', () => {
  const plan = generateSchedule({ frequency: 'daily', firstDueDate: '2026-10-23', totalAmount: 100050, installmentAmount: 30000 });
  assert.deepEqual(plan.map(p => p.amount), [30000, 30000, 30000, 10050]);
  assert.equal(plan.reduce((s, p) => s + p.amount, 0), 100050);
  assert.equal(plan[3].dueDate, '2026-10-26');
});
test('schedule: daily can skip Sundays (2026-10-25 is a Sunday)', () => {
  const plan = generateSchedule({ frequency: 'daily', firstDueDate: '2026-10-24', totalAmount: 30000, installmentAmount: 10000, skipSundays: true });
  assert.deepEqual(plan.map(p => p.dueDate), ['2026-10-24', '2026-10-26', '2026-10-27']);
});
test('schedule: weekly, biweekly, monthly (month-end clamp, no drift), custom', () => {
  assert.deepEqual(generateSchedule({ frequency: 'weekly', firstDueDate: '2026-10-23', totalAmount: 30000, installmentCount: 3 }).map(p => p.dueDate), ['2026-10-23', '2026-10-30', '2026-11-06']);
  assert.deepEqual(generateSchedule({ frequency: 'biweekly', firstDueDate: '2026-10-23', totalAmount: 20000, installmentCount: 2 }).map(p => p.dueDate), ['2026-10-23', '2026-11-06']);
  assert.deepEqual(generateSchedule({ frequency: 'monthly', firstDueDate: '2026-01-31', totalAmount: 30000, installmentCount: 3 }).map(p => p.dueDate), ['2026-01-31', '2026-02-28', '2026-03-31']);
  const c = generateSchedule({ frequency: 'custom', firstDueDate: '2026-11-01', totalAmount: 10000, customDueDates: ['2026-11-01', '2026-12-15'] });
  assert.deepEqual(c.map(p => p.amount), [5000, 5000]);
});
test('schedule: count mode puts the rounding remainder in the last installment; validation', () => {
  const plan = generateSchedule({ frequency: 'weekly', firstDueDate: '2026-10-23', totalAmount: 10000, installmentCount: 3 });
  assert.deepEqual(plan.map(p => p.amount), [3333, 3333, 3334]);
  assert.throws(() => generateSchedule({ frequency: 'weekly', firstDueDate: '2026-10-23', totalAmount: 10000 }));
  assert.throws(() => generateSchedule({ frequency: 'weekly', firstDueDate: '2026-10-23', totalAmount: 10000, installmentAmount: 1, installmentCount: 2 }));
  const d = describeSchedule(plan);
  assert.equal(d.additionalFees, 0); assert.equal(d.totalScheduled, 10000);
});

test('days overdue and statuses (grace period, partial, paid, cancelled)', () => {
  const [i1, i2, i3] = makeInstallments('c', 3, 10000, '2026-10-20'); // due 20th, 21st, 22nd
  const today = '2026-10-23';
  assert.equal(daysOverdue(i1, today), 3);
  assert.equal(installmentStatus(i1, today), 'overdue');
  assert.equal(installmentStatus(i1, today, 3), 'due_today', 'within grace is not yet flagged overdue');
  assert.equal(installmentStatus(i1, today, 2), 'overdue');
  const part = { ...i2, allocatedAmount: 4000 };
  assert.equal(installmentStatus(part, '2026-10-21'), 'partially_paid');
  assert.equal(installmentStatus(part, today), 'overdue', 'unpaid remainder still becomes overdue');
  assert.equal(daysOverdue({ ...i3, allocatedAmount: 10000 }, today), 0);
  assert.equal(installmentStatus({ ...i3, allocatedAmount: 10000 }, today), 'paid');
  assert.equal(installmentStatus({ ...i3, state: 'cancelled' }, today), 'cancelled');
  assert.equal(installmentStatus({ ...i3, state: 'rescheduled' }, today), 'rescheduled');
  assert.equal(installmentStatus(makeInstallments('x', 1, 100, '2026-10-24')[0], today), 'upcoming');
  assert.equal(installmentStatus(makeInstallments('x', 1, 100, '2026-10-23')[0], today), 'due_today');
});
test('account summary keeps scheduled / paid / outstanding / overdue separate', () => {
  const list = makeInstallments('c', 5, 10000, '2026-10-21'); // due 21,22,23,24,25 ; today=23
  list[0].allocatedAmount = 10000; list[0].lastPaymentDate = '2026-10-21'; list[1].allocatedAmount = 2500;
  const s = summarizeAccount(list, '2026-10-23');
  assert.deepEqual(s, { totalScheduled: 50000, totalPaid: 12500, outstandingBalance: 37500, amountDueNow: 7500 + 10000,
    overdueAmount: 7500, overdueInstallments: 1, daysPastDue: 1, nextDueDate: '2026-10-22', lastPaymentDate: '2026-10-21' });
});
