import { test } from 'node:test';
import assert from 'node:assert/strict';
import { allocatePayment } from '../src/allocation.ts';
import { summarizeAccount, outstanding } from '../src/installments.ts';
import { generateReceiptNo, verificationCode, buildReceiptView } from '../src/receipt.ts';
import { summarizeCollections } from '../src/reports.ts';
import { ForbiddenError, ConflictError, ValidationError } from '../src/errors.ts';
import { BIZ, auditor, empA, empB, employer, makeInstallments, pay, setup } from './helpers.ts';

const TODAY = '2026-10-23';

test('allocation: partial payment leaves the installment unpaid with the remainder', () => {
  const r = allocatePayment(4000, makeInstallments(), TODAY);
  assert.deepEqual(r.allocations, [{ installmentId: 'c1-i1', amount: 4000, kind: 'due' }]);
  assert.equal(r.creditAmount, 0);
});
test('allocation: oldest first, one payment covers several installments', () => {
  const list = makeInstallments('c1', 5, 10000, '2026-10-20'); // 20,21,22,23,24 ; today 23
  const r = allocatePayment(25000, list, TODAY);
  assert.deepEqual(r.allocations.map(a => [a.installmentId, a.amount]), [['c1-i1', 10000], ['c1-i2', 10000], ['c1-i3', 5000]]);
});
test('allocation: advance flows to future installments; overpayment beyond contract becomes credit', () => {
  const adv = allocatePayment(20000, makeInstallments(), TODAY);
  assert.deepEqual(adv.allocations.map(a => a.kind), ['due', 'advance']);
  const over = allocatePayment(70000, makeInstallments(), TODAY);
  assert.equal(over.creditAmount, 20000);
  assert.equal(over.allocations.reduce((s, a) => s + a.amount, 0) + over.creditAmount, 70000);
  const noAdv = allocatePayment(30000, makeInstallments(), TODAY, { allowAdvance: false });
  assert.equal(noAdv.allocations.length, 1); assert.equal(noAdv.creditAmount, 20000);
});

test('record payment: allocation history, balances, receipt code and audit are saved together', async () => {
  const { repo, service } = setup();
  const { payment, duplicate } = await service.recordPayment(empA, pay({ amount: 15000 }));
  assert.equal(duplicate, false);
  assert.deepEqual(payment.allocations.map(a => a.amount), [10000, 5000]);
  assert.match(payment.verificationCode, /^[0-9A-Z]{5}-[0-9A-Z]{5}$/);
  const inst = await repo.transaction(tx => tx.listInstallments(BIZ, 'c1'));
  assert.equal(summarizeAccount(inst, TODAY).totalPaid, 15000);
  assert.equal(outstanding(inst[1]), 5000);
  assert.equal(repo.state.audits.length, 1);
});
test('overpayment is held as customer credit and never discarded', async () => {
  const { repo, service } = setup();
  const { payment } = await service.recordPayment(empA, pay({ amount: 60000 }));
  assert.equal(payment.creditAmount, 10000);
  const c = await repo.transaction(tx => tx.getCustomer(BIZ, 'c1'));
  assert.equal(c!.creditBalance, 10000);
});

test('duplicate prevention: same transaction submitted twice returns the original payment', async () => {
  const { repo, service } = setup();
  const input = pay();
  const first = await service.recordPayment(empA, input);
  const second = await service.recordPayment(empA, { ...input });
  assert.equal(second.duplicate, true); assert.equal(second.payment.id, first.payment.id);
  assert.equal(repo.state.payments.size, 1);
  const inst = await repo.transaction(tx => tx.listInstallments(BIZ, 'c1'));
  assert.equal(summarizeAccount(inst, TODAY).totalPaid, 10000, 'money allocated only once');
});
test('duplicate prevention: two devices / parallel requests with the same key create ONE payment', async () => {
  const { repo, service } = setup();
  const input = pay();
  const results = await Promise.all([service.recordPayment(empA, input), service.recordPayment(empA, { ...input }), service.recordPayment(empA, { ...input })]);
  assert.equal(results.filter(r => !r.duplicate).length, 1);
  assert.equal(repo.state.payments.size, 1);
});
test('same key with different amount is rejected; reused receipt number is rejected', async () => {
  const { service } = setup();
  const a = pay(); await service.recordPayment(empA, a);
  await assert.rejects(service.recordPayment(empA, { ...a, amount: 99999 }), (e: any) => e instanceof ConflictError && e.code === 'IDEMPOTENCY_MISMATCH');
  await assert.rejects(service.recordPayment(empA, pay({ receiptNo: a.receiptNo })), (e: any) => e.code === 'RECEIPT_DUPLICATE');
});
test('receipt numbers are unique per payment and stable', () => {
  const a = generateReceiptNo({ employeeCode: 'emp-001', deviceCode: 'a7k2zz', businessDate: '2026-10-23', sequence: 1 });
  const b = generateReceiptNo({ employeeCode: 'emp-001', deviceCode: 'a7k2zz', businessDate: '2026-10-23', sequence: 2 });
  assert.equal(a, 'OR-EMP001-A7K2-20261023-0001'); assert.notEqual(a, b);
  const base = { businessId: 'b', id: 'p', receiptNo: a, customerId: 'c', amount: 100, paidAt: 'x' };
  assert.equal(verificationCode('s', base), verificationCode('s', base));
  assert.notEqual(verificationCode('s', base), verificationCode('other', base));
  assert.notEqual(verificationCode('s', base), verificationCode('s', { ...base, amount: 101 }));
});
test('offline receipt view is clearly provisional, then cloud-confirmed with the same number', async () => {
  const { service } = setup();
  const input = pay({ recordedOffline: true });
  const draft = { receiptNo: input.receiptNo, amount: input.amount, method: input.method, paidAt: input.paidAt };
  const before = buildReceiptView(draft, null);
  assert.equal(before.syncStatus, 'local_only'); assert.match(before.notice!, /LOCALLY RECORDED/); assert.equal(before.verificationCode, null);
  const { payment } = await service.recordPayment(empA, input);
  const after = buildReceiptView(draft, payment);
  assert.equal(after.receiptNo, before.receiptNo); assert.equal(after.syncStatus, 'cloud_confirmed'); assert.ok(after.verificationCode);
});

test('authorization: employee cannot pay another employee’s customer or impersonate another employee', async () => {
  const { repo, service } = setup();
  await assert.rejects(service.recordPayment(empB, pay({ employeeId: 'emp-b' })), ForbiddenError);
  await assert.rejects(service.recordPayment(empB, pay({ employeeId: 'emp-a' })), ForbiddenError);
  assert.equal(repo.state.payments.size, 0);
});
test('authorization: read-only auditor, other business, and non-employer reversal are blocked', async () => {
  const { service } = setup();
  await assert.rejects(service.recordPayment(auditor, pay()), ForbiddenError);
  await assert.rejects(service.recordPayment({ ...empA, businessId: 'other' }, pay()), ForbiddenError);
  const { payment } = await service.recordPayment(empA, pay());
  await assert.rejects(service.reversePayment(empA, { businessId: BIZ, paymentId: payment.id, reason: 'I made a mistake' }), ForbiddenError);
  await assert.rejects(service.reversePayment(auditor, { businessId: BIZ, paymentId: payment.id, reason: 'I made a mistake' }), ForbiddenError);
});
test('validation: zero/negative/float amounts, bad timestamps, bad GPS, inactive account', async () => {
  const { repo, service } = setup();
  for (const amount of [0, -5, 10.5]) await assert.rejects(service.recordPayment(empA, pay({ amount })), ValidationError);
  await assert.rejects(service.recordPayment(empA, pay({ paidAt: '2026-10-23 09:00' })), ValidationError);
  await assert.rejects(service.recordPayment(empA, pay({ paidAt: '2030-01-01T00:00:00+08:00' })), ValidationError);
  await assert.rejects(service.recordPayment(empA, pay({ location: { lat: 200, lng: 0, capturedAt: '2026-10-23T09:00:00+08:00' } })), ValidationError);
  const ok = await service.recordPayment(empA, pay({ location: null })); // GPS unavailable/denied is allowed
  assert.equal(ok.payment.location, null);
  repo.state.customers.get(`${BIZ}:c1`)!.status = 'disputed';
  await assert.rejects(service.recordPayment(empA, pay()), (e: any) => e.code === 'ACCOUNT_NOT_ACTIVE');
});
test('atomicity: a failure after balances are updated rolls everything back', async () => {
  const { repo, service } = setup();
  repo.failNextAudit = true;
  await assert.rejects(service.recordPayment(empA, pay({ amount: 20000 })));
  assert.equal(repo.state.payments.size, 0);
  const inst = await repo.transaction(tx => tx.listInstallments(BIZ, 'c1'));
  assert.equal(summarizeAccount(inst, TODAY).totalPaid, 0);
});

test('reversal: restores balances, links reason/user/time, cannot be repeated, original payment kept', async () => {
  const { repo, service } = setup();
  const { payment } = await service.recordPayment(empA, pay({ amount: 60000 })); // 50000 allocated + 10000 credit
  await assert.rejects(service.reversePayment(employer, { businessId: BIZ, paymentId: payment.id, reason: 'x' }), ValidationError);
  const rev = await service.reversePayment(employer, { businessId: BIZ, paymentId: payment.id, reason: 'Wrong customer' });
  assert.equal(rev.paymentId, payment.id); assert.equal(rev.reversedBy, employer.userId);
  const inst = await repo.transaction(tx => tx.listInstallments(BIZ, 'c1'));
  assert.equal(summarizeAccount(inst, TODAY).totalPaid, 0);
  assert.equal((await repo.transaction(tx => tx.getCustomer(BIZ, 'c1')))!.creditBalance, 0);
  assert.ok(repo.state.payments.has(`${BIZ}:${payment.id}`), 'original record is preserved');
  await assert.rejects(service.reversePayment(employer, { businessId: BIZ, paymentId: payment.id, reason: 'Again please' }), (e: any) => e.code === 'ALREADY_REVERSED');
});

test('report totals reconcile with transaction records; reversed payments excluded; by method/employee', async () => {
  const { repo, service } = setup();
  const p1 = (await service.recordPayment(empA, pay({ amount: 10000, method: 'cash' }))).payment;
  const p2 = (await service.recordPayment(empA, pay({ amount: 5000, method: 'e_wallet' }))).payment;
  const p3 = (await service.recordPayment(empA, pay({ amount: 80000, method: 'bank_transfer' }))).payment; // creates credit
  await service.reversePayment(employer, { businessId: BIZ, paymentId: p1.id, reason: 'Duplicate entry by mistake' });
  const all = [...repo.state.payments.values()];
  const reversed = new Set([...repo.state.reversals.values()].map(r => r.paymentId));
  const s = summarizeCollections(all, reversed, '2026-10-23', '2026-10-23');
  assert.equal(s.total, p2.amount + p3.amount);
  assert.equal(s.byMethod.cash, 0); assert.equal(s.byMethod.e_wallet, 5000); assert.equal(s.byMethod.bank_transfer, 80000);
  assert.equal(s.byEmployee['emp-a'], 85000);
  assert.equal(s.reconciles, true);
  assert.equal(summarizeCollections(all, reversed, '2026-10-24', '2026-10-30').total, 0);
});
