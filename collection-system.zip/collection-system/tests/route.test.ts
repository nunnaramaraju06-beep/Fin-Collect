import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildRoute, completionReport, haversineKm, markVisited, nextStop, routeProgress, skipStop, toStops } from '../src/route.ts';
import type { RouteCandidate } from '../src/route.ts';

const cand = (id: string, over: Partial<RouteCandidate> = {}): RouteCandidate =>
  ({ customerId: id, name: id, lat: null, lng: null, priority: 0, dueTodayAmount: 0, overdueAmount: 0, daysPastDue: 0, ...over });
const ids = (r: { customerId: string }[]) => r.map(x => x.customerId);
const AT = '2026-10-23T10:00:00+08:00';

test('haversine distance is sensible (Manila to Cebu is roughly 570 km)', () => {
  const d = haversineKm({ lat: 14.5995, lng: 120.9842 }, { lat: 10.3157, lng: 123.8854 });
  assert.ok(d > 560 && d < 590, `got ${d}`);
  assert.equal(haversineKm({ lat: 1, lng: 1 }, { lat: 1, lng: 1 }), 0);
});

test('route: due-today first, then overdue (highlighted); customers with nothing due are left out', () => {
  const r = buildRoute([
    cand('late', { overdueAmount: 5000, daysPastDue: 9 }), cand('today', { dueTodayAmount: 1000 }), cand('nothing'),
    cand('both', { dueTodayAmount: 1000, overdueAmount: 2000, daysPastDue: 2 }),
  ]);
  assert.deepEqual(ids(r), ['both', 'today', 'late']);
  assert.deepEqual(r.map(x => x.position), [1, 2, 3]);
  assert.deepEqual(r.map(x => x.highlightOverdue), [true, false, true]);
  assert.equal(r[0].amountDue, 3000);
  assert.deepEqual(ids(buildRoute([cand('nothing')], { includeAll: true })), ['nothing']);
});
test('route: inside a tier, higher priority first, then longer overdue, then name', () => {
  const r = buildRoute([
    cand('c', { dueTodayAmount: 1, priority: 0 }), cand('a', { dueTodayAmount: 1, priority: 0 }), cand('vip', { dueTodayAmount: 1, priority: 5 }),
    cand('o1', { overdueAmount: 1, daysPastDue: 3 }), cand('o2', { overdueAmount: 1, daysPastDue: 10 }),
  ]);
  assert.deepEqual(ids(r), ['vip', 'a', 'c', 'o2', 'o1']);
});
test('route: duplicates in the input appear once', () => {
  assert.deepEqual(ids(buildRoute([cand('x', { dueTodayAmount: 1 }), cand('x', { dueTodayAmount: 1 })])), ['x']);
});
test('route: nearest mode walks to the closest customer next; no-GPS customers go last; tiers still win', () => {
  const start = { lat: 14.0, lng: 121.0 };
  const r = buildRoute([
    cand('far', { dueTodayAmount: 1, lat: 14.010, lng: 121.0 }), cand('near', { dueTodayAmount: 1, lat: 14.001, lng: 121.0 }),
    cand('mid', { dueTodayAmount: 1, lat: 14.002, lng: 121.0 }), cand('nogps', { dueTodayAmount: 1 }),
    cand('overdueClose', { overdueAmount: 1, daysPastDue: 1, lat: 14.0005, lng: 121.0 }),
  ], { mode: 'nearest', start });
  assert.deepEqual(ids(r), ['near', 'mid', 'far', 'nogps', 'overdueClose']);
});
test('route: employer manual order is placed first; unknown ids are ignored; the rest keep suggested order', () => {
  const list = [cand('a', { dueTodayAmount: 1, priority: 3 }), cand('b', { dueTodayAmount: 1, priority: 2 }), cand('c', { dueTodayAmount: 1, priority: 1 })];
  assert.deepEqual(ids(buildRoute(list, { manualOrder: ['c', 'ghost', 'c'] })), ['c', 'a', 'b']);
});

test('stops: follow the route one customer at a time with progress, skip reasons and completion', () => {
  let stops = toStops(buildRoute([cand('a', { dueTodayAmount: 1, priority: 3 }), cand('b', { dueTodayAmount: 1, priority: 2 }), cand('c', { dueTodayAmount: 1, priority: 1 })]));
  assert.equal(nextStop(stops)!.customerId, 'a');
  assert.deepEqual(routeProgress(stops), { total: 3, visited: 0, skipped: 0, pending: 3, percent: 0, complete: false, nextCustomerId: 'a' });
  const before = stops;
  stops = markVisited(stops, 'a', AT);
  assert.equal(before[0].status, 'pending', 'original array is not mutated');
  assert.throws(() => skipStop(stops, 'b', '  ', AT), /reason/);
  stops = skipStop(stops, 'b', 'Customer not home', AT);
  assert.equal(routeProgress(stops).percent, 67); assert.equal(routeProgress(stops).nextCustomerId, 'c');
  stops = markVisited(stops, 'c', AT);
  const p = routeProgress(stops);
  assert.deepEqual([p.percent, p.complete, p.nextCustomerId], [100, true, null]);
  const rep = completionReport(stops, { a: 5000, c: 2500, zzz: 99999 });
  assert.equal(rep.totalCollected, 7500); assert.deepEqual(rep.skippedStops, [{ customerId: 'b', reason: 'Customer not home' }]);
});
test('stops: cannot complete a stop twice or complete a customer who is not on the route', () => {
  const stops = markVisited(toStops(buildRoute([cand('a', { dueTodayAmount: 1 })])), 'a', AT);
  assert.throws(() => markVisited(stops, 'a', AT), /already completed/);
  assert.throws(() => skipStop(stops, 'a', 'later', AT), /already completed/);
  assert.throws(() => markVisited(stops, 'nobody', AT), /not on today/);
  assert.equal(routeProgress([]).percent, 0);
});
