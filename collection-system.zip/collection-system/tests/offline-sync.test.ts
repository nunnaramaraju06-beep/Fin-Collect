import { test } from 'node:test';
import assert from 'node:assert/strict';
import { InMemoryQueueStore, NetworkError, SyncQueue } from '../src/sync-queue.ts';
import type { QueuedOp } from '../src/sync-queue.ts';
import { processPaymentOp } from '../src/sync-adapter.ts';
import { reconcileCash } from '../src/reconciliation.ts';
import { BIZ, empA, empB, pay, setup } from './helpers.ts';

function newQueue(clock = { t: 1_000_000 }) {
  return { clock, q: new SyncQueue(new InMemoryQueueStore(), { now: () => clock.t, baseDelayMs: 1000 }) };
}
const enqueuePayment = (q: SyncQueue, input = pay({ recordedOffline: true })) => q.enqueue({ opId: input.deviceTransactionId, type: 'payment', payload: input }).then(() => input);

test('offline collections queue locally, then sync once connectivity returns (original IDs preserved)', async () => {
  const { service, repo } = setup();
  const { q } = newQueue();
  const a = await enqueuePayment(q, pay({ recordedOffline: true, amount: 10000 }));
  const b = await enqueuePayment(q, pay({ recordedOffline: true, amount: 5000 }));
  assert.equal((await q.pending()).length, 2);
  const r = await q.flush(op => processPaymentOp(service, empA, op));
  assert.deepEqual([r.synced, r.networkFailed], [2, false]);
  assert.equal((await q.pending()).length, 0);
  const saved = [...repo.state.payments.values()].map(p => [p.deviceTransactionId, p.receiptNo]);
  assert.deepEqual(saved.sort(), [[a.deviceTransactionId, a.receiptNo], [b.deviceTransactionId, b.receiptNo]].sort());
});

test('enqueueing the same operation twice keeps a single queue item', async () => {
  const { q } = newQueue(); const input = pay();
  await enqueuePayment(q, input); await enqueuePayment(q, input);
  assert.equal((await q.pending()).length, 1);
});

test('network failure BEFORE the server sees it: stays pending, backs off, retries later', async () => {
  const { service, repo } = setup();
  const { q, clock } = newQueue();
  await enqueuePayment(q);
  const down = await q.flush(async () => { throw new NetworkError('offline'); });
  assert.equal(down.networkFailed, true); assert.equal((await q.pending()).length, 1);
  const tooSoon = await q.flush(op => processPaymentOp(service, empA, op));
  assert.equal(repo.state.payments.size, 0, 'backoff respected');
  clock.t += 60_000;
  const ok = await q.flush(op => processPaymentOp(service, empA, op));
  assert.equal(ok.synced, 1); assert.equal(repo.state.payments.size, 1); assert.equal(tooSoon.networkFailed, true);
});

test('network failure AFTER the server saved it (response lost): retry is a safe duplicate, money counted once', async () => {
  const { service, repo } = setup();
  const { q } = newQueue();
  await enqueuePayment(q);
  const lost = await q.flush(async op => { await processPaymentOp(service, empA, op); throw new NetworkError('response lost'); });
  assert.equal(lost.networkFailed, true); assert.equal(repo.state.payments.size, 1);
  const retry = await q.flush(op => processPaymentOp(service, empA, op), { force: true });
  assert.equal(retry.duplicates, 1); assert.equal(repo.state.payments.size, 1);
  assert.equal((await q.pending()).length, 0);
});

test('two devices submit the same transaction: one payment is recorded', async () => {
  const { service, repo } = setup();
  const input = pay({ recordedOffline: true });
  const [d1, d2] = [newQueue().q, newQueue().q];
  await enqueuePayment(d1, input); await enqueuePayment(d2, input);
  const [r1, r2] = await Promise.all([d1.flush(op => processPaymentOp(service, empA, op)), d2.flush(op => processPaymentOp(service, empA, op))]);
  assert.equal(r1.synced + r2.synced, 1); assert.equal(r1.duplicates + r2.duplicates, 1);
  assert.equal(repo.state.payments.size, 1);
});

test('rejected and conflicting offline records are surfaced, never silently dropped or overwritten', async () => {
  const { service, repo } = setup();
  const { q } = newQueue();
  await enqueuePayment(q, pay({ recordedOffline: true, amount: -1 }));                 // invalid -> rejected
  const first = await enqueuePayment(q, pay({ recordedOffline: true }));
  await q.flush(op => processPaymentOp(service, empA, op));
  const clash = pay({ recordedOffline: true, receiptNo: first.receiptNo });             // reused receipt no -> conflict
  await enqueuePayment(q, clash); await q.flush(op => processPaymentOp(service, empA, op));
  const attention = await q.needsAttention();
  assert.deepEqual(attention.map(o => o.status).sort(), ['conflict', 'rejected']);
  assert.ok(attention.every(o => o.lastError));
  assert.equal(repo.state.payments.size, 1);
});

test('employee B cannot push a payment for employee A’s customer via sync', async () => {
  const { service, repo } = setup();
  const { q } = newQueue();
  await enqueuePayment(q, pay({ employeeId: 'emp-b', recordedOffline: true }));
  const r = await q.flush(op => processPaymentOp(service, empB, op));
  assert.equal(r.rejected, 1); assert.equal(repo.state.payments.size, 0);
});

test('unexpected server errors are not swallowed (client would see HTTP 5xx and retry)', async () => {
  const { service, repo } = setup();
  const { q } = newQueue(); await enqueuePayment(q);
  repo.failNextAudit = true;
  await assert.rejects(q.flush((op: QueuedOp) => processPaymentOp(service, empA, op)));
  assert.equal(repo.state.payments.size, 0);
  assert.equal((await q.pending()).length, 1, 'still queued for retry');
});

test('cash reconciliation: expected = opening + cash collections - cash expenses - refunds - handed over', () => {
  const r = reconcileCash({ openingCash: 50000, cashCollections: 250000, cashExpenses: 20000, cashRefunds: 0, handedOver: 200000, actualOnHand: 80000 });
  assert.deepEqual(r, { expectedOnHand: 80000, difference: 0, status: 'balanced' });
  assert.deepEqual(reconcileCash({ openingCash: 0, cashCollections: 100000, cashExpenses: 0, cashRefunds: 0, handedOver: 90000, actualOnHand: 9000 }),
    { expectedOnHand: 10000, difference: -1000, status: 'shortage' });
  assert.equal(reconcileCash({ openingCash: 0, cashCollections: 100, cashExpenses: 0, cashRefunds: 0, handedOver: 0, actualOnHand: 150 }).status, 'excess');
  assert.throws(() => reconcileCash({ openingCash: 0, cashCollections: 1.5, cashExpenses: 0, cashRefunds: 0, handedOver: 0, actualOnHand: 0 }));
});
