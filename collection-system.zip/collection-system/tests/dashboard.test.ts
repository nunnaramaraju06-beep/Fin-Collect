import { test } from 'node:test';
import assert from 'node:assert/strict';
import { startOfMonth, startOfWeek } from '../src/dates.ts';
import { employeeDashboard, employerDashboard, unusualPayments } from '../src/dashboard.ts';
import type { CustomerRow } from '../src/dashboard.ts';
import { shiftCashFigures } from '../src/shift.ts';
import { reconcileCash } from '../src/reconciliation.ts';
import { toStops, buildRoute, markVisited, skipStop } from '../src/route.ts';
import { fakePayment as fp } from './helpers.ts';

const TODAY = '2026-10-23'; // a Friday in Asia/Manila

test('week starts Monday and month starts on the 1st', () => {
  assert.equal(startOfWeek('2026-10-23'), '2026-10-19'); assert.equal(startOfWeek('2026-10-19'), '2026-10-19');
  assert.equal(startOfWeek('2026-10-25'), '2026-10-19', 'Sunday belongs to the week that began Monday'); assert.equal(startOfMonth('2026-10-23'), '2026-10-01');
});

test('employee dashboard: totals, target, visits, overdue and offline status; reversed and other employees excluded', () => {
  const payments = [
    fp({ amount: 10000, method: 'cash', customerId: 'c1' }), fp({ amount: 5000, method: 'e_wallet', customerId: 'c2' }),
    fp({ amount: 3000, paidAt: '2026-10-19T09:00:00+08:00' }),          // Monday: this week, not today
    fp({ amount: 7000, paidAt: '2026-10-05T09:00:00+08:00' }),          // earlier this month
    fp({ amount: 9000, paidAt: '2026-09-30T09:00:00+08:00' }),          // last month
    fp({ amount: 40000, employeeId: 'emp-b' }),                         // someone else
    fp({ amount: 2000, paidAt: '2026-10-22T16:30:00Z' }),               // 00:30 on the 23rd in Manila -> today
  ];
  const reversed = new Set([payments[3].id]);
  let stops = toStops(buildRoute([{ customerId: 'c1', name: 'a', lat: null, lng: null, priority: 0, dueTodayAmount: 1, overdueAmount: 0, daysPastDue: 0 },
    { customerId: 'c2', name: 'b', lat: null, lng: null, priority: 0, dueTodayAmount: 1, overdueAmount: 0, daysPastDue: 0 },
    { customerId: 'c3', name: 'c', lat: null, lng: null, priority: 0, dueTodayAmount: 1, overdueAmount: 0, daysPastDue: 0 }]));
  stops = markVisited(stops, 'c1', 'x'); stops = skipStop(stops, 'c2', 'No one home', 'x');
  const d = employeeDashboard({ today: TODAY, employeeId: 'emp-a', dailyTarget: 20000, payments, reversedIds: reversed, stops, pendingOffline: 2, lastSyncAt: '2026-10-23T08:00:00+08:00',
    customers: [{ customerId: 'c1', dueTodayAmount: 10000, overdueAmount: 0 }, { customerId: 'c2', dueTodayAmount: 5000, overdueAmount: 20000, followUpDate: '2026-10-22' }, { customerId: 'c3', dueTodayAmount: 0, overdueAmount: 1500, followUpDate: '2026-10-30' }] });
  assert.equal(d.collectedToday, 17000);                       // 10000 + 5000 + 2000
  assert.equal(d.cashCollectedToday, 12000); assert.equal(d.nonCashCollectedToday, 5000);
  assert.equal(d.collectedWeek, 20000);                        // + Monday 3000
  assert.equal(d.collectedMonth, 20000, 'reversed 7000 and last month 9000 excluded');
  assert.equal(d.targetPercent, 85);
  assert.deepEqual([d.assignedToday, d.visited, d.failedAttempts, d.toVisit, d.successfulCollections], [3, 1, 1, 1, 2]);
  assert.deepEqual([d.amountDueToday, d.totalOverdue, d.followUpsRequired, d.pendingOffline], [15000, 21500, 1, 2]);
});
test('employee dashboard: zero target gives 0%, never a divide-by-zero', () => {
  const d = employeeDashboard({ today: TODAY, employeeId: 'emp-a', dailyTarget: 0, payments: [fp()], reversedIds: new Set(), stops: [], customers: [], pendingOffline: 0, lastSyncAt: null });
  assert.equal(d.targetPercent, 0); assert.equal(d.collectedToday, 10000);
});

const rows: CustomerRow[] = [
  { customerId: 'c1', employeeId: 'emp-a', status: 'active', municipality: 'Lipa', barangay: 'Sabang', outstanding: 50000, dueTodayAmount: 10000, overdueAmount: 0 },
  { customerId: 'c2', employeeId: 'emp-a', status: 'active', municipality: 'Lipa', barangay: 'Marawoy', outstanding: 30000, dueTodayAmount: 0, overdueAmount: 20000 },
  { customerId: 'c3', employeeId: 'emp-b', status: 'active', municipality: 'Batangas', barangay: 'Poblacion', outstanding: 80000, dueTodayAmount: 5000, overdueAmount: 5000 },
  { customerId: 'c4', employeeId: 'emp-b', status: 'completed', municipality: 'Batangas', barangay: 'Poblacion', outstanding: 0, dueTodayAmount: 0, overdueAmount: 0 },
  { customerId: 'c5', employeeId: 'emp-a', status: 'prospect', municipality: 'Lipa', barangay: 'Sabang', outstanding: 99999, dueTodayAmount: 99999, overdueAmount: 99999 },
];
const pays = [
  fp({ customerId: 'c1', employeeId: 'emp-a', amount: 10000, method: 'cash' }),
  fp({ customerId: 'c2', employeeId: 'emp-a', amount: 4000, method: 'bank_transfer' }),
  fp({ customerId: 'c3', employeeId: 'emp-b', amount: 6000, method: 'e_wallet' }),
  fp({ customerId: 'c3', employeeId: 'emp-b', amount: 1000, method: 'cash', paidAt: '2026-10-02T09:00:00+08:00' }),
  fp({ customerId: 'c1', employeeId: 'emp-a', amount: 777, method: 'cash' }),
];
const dash = (filters = {}, reversedIds = new Set<string>()) =>
  employerDashboard({ today: TODAY, customers: rows, payments: pays, reversedIds, dailyTargets: { 'emp-a': 20000, 'emp-b': 5000 }, filters });

test('employer dashboard: totals, counts (only active accounts carry balances), method breakdown, ranking, targets', () => {
  const d = dash();
  assert.deepEqual([d.collectedToday, d.collectedMonth], [20777, 21777]);
  assert.deepEqual(d.range.byMethod, { cash: 11777, bank_transfer: 4000, e_wallet: 6000, other: 0 });
  assert.equal(d.range.total, 21777);
  assert.deepEqual([d.outstandingTotal, d.overdueTotal, d.uncollectedScheduledNow], [160000, 25000, 40000]);
  assert.deepEqual([d.activeCustomers, d.customersDueToday, d.overdueCustomers, d.fullyPaidAccounts], [3, 2, 2, 1]);
  assert.deepEqual(d.ranking.map(r => [r.employeeId, r.collectedToday, r.collectedMonth, r.targetPercent]), [['emp-a', 14777, 14777, 74], ['emp-b', 6000, 7000, 120]].sort((x, y) => (y[2] as number) - (x[2] as number)));
});
test('employer dashboard: filters by employee, municipality, method and date range; reversals excluded', () => {
  assert.equal(dash({ employeeId: 'emp-b' }).collectedMonth, 7000);
  assert.equal(dash({ municipality: 'Lipa' }).collectedMonth, 14777);
  assert.equal(dash({ method: 'cash' }).collectedMonth, 11777);
  assert.equal(dash({ from: '2026-10-01', to: '2026-10-10' }).range.total, 1000);
  const r = dash({}, new Set([pays[0].id]));
  assert.equal(r.collectedToday, 10777);
  assert.equal(dash({ municipality: 'Lipa' }).activeCustomers, 2);
});

test('unusual payments: large amount, late offline sync, future-dated, and likely double entry', () => {
  const big = fp({ amount: 6_000_000 });
  const late = fp({ recordedOffline: true, paidAt: '2026-10-20T09:00:00+08:00', syncedAt: '2026-10-23T09:00:00+08:00' });
  const future = fp({ paidAt: '2026-10-23T12:00:00+08:00', syncedAt: '2026-10-23T09:00:00+08:00' });
  const d1 = fp({ customerId: 'cx', amount: 1234, paidAt: '2026-10-23T09:00:00+08:00' });
  const d2 = fp({ customerId: 'cx', amount: 1234, paidAt: '2026-10-23T09:04:00+08:00' });
  const ok = fp({ customerId: 'cy', amount: 1234, paidAt: '2026-10-23T09:30:00+08:00' });
  const flags = Object.fromEntries(unusualPayments([big, late, future, d1, d2, ok]).map(f => [f.paymentId, f.reasons]));
  assert.deepEqual(flags[big.id], ['large_amount']); assert.deepEqual(flags[late.id], ['late_sync']); assert.deepEqual(flags[future.id], ['future_dated']);
  assert.deepEqual(flags[d2.id], ['possible_duplicate']); assert.equal(flags[d1.id], undefined); assert.equal(flags[ok.id], undefined);
});

test('shift cash figures feed the reconciliation: own, live, same-day cash only; approved cash expenses only', () => {
  const payments = [
    fp({ employeeId: 'emp-a', amount: 100000, method: 'cash' }), fp({ employeeId: 'emp-a', amount: 50000, method: 'e_wallet' }),
    fp({ employeeId: 'emp-a', amount: 7000, method: 'cash' }),                                   // will be reversed
    fp({ employeeId: 'emp-a', amount: 9000, method: 'cash', paidAt: '2026-10-22T09:00:00+08:00' }), // yesterday
    fp({ employeeId: 'emp-b', amount: 88000, method: 'cash' }),                                  // someone else
  ];
  const expenses = [
    { id: 'e1', employeeId: 'emp-a', amount: 15000, method: 'cash' as const, status: 'approved' as const, incurredAt: '2026-10-23T11:00:00+08:00' },
    { id: 'e2', employeeId: 'emp-a', amount: 99000, method: 'cash' as const, status: 'pending' as const, incurredAt: '2026-10-23T11:00:00+08:00' },
    { id: 'e3', employeeId: 'emp-a', amount: 5000, method: 'other' as const, status: 'approved' as const, incurredAt: '2026-10-23T11:00:00+08:00' },
  ];
  const f = shiftCashFigures({ date: TODAY, employeeId: 'emp-a', payments, reversedIds: new Set([payments[2].id]), expenses });
  assert.deepEqual(f, { cashCollections: 100000, nonCashCollections: 50000, cashExpenses: 15000 });
  const r = reconcileCash({ openingCash: 20000, cashCollections: f.cashCollections, cashExpenses: f.cashExpenses, cashRefunds: 0, handedOver: 90000, actualOnHand: 15000 });
  assert.deepEqual(r, { expectedOnHand: 15000, difference: 0, status: 'balanced' });
});
