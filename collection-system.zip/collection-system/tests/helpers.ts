import { InMemoryRepo } from '../src/repo.ts';
import { PaymentService } from '../src/payments.ts';
import type { PaymentInput } from '../src/payments.ts';
import type { Actor, Installment } from '../src/types.ts';

export const BIZ = 'biz-1';
export const employer: Actor = { userId: 'u-boss', businessId: BIZ, role: 'employer' };
export const empA: Actor = { userId: 'u-a', businessId: BIZ, role: 'employee', employeeId: 'emp-a' };
export const empB: Actor = { userId: 'u-b', businessId: BIZ, role: 'employee', employeeId: 'emp-b' };
export const auditor: Actor = { userId: 'u-aud', businessId: BIZ, role: 'accountant' };

/** 5 daily installments of ₱100.00 starting 2026-10-23 (the "today" used in tests). */
export function makeInstallments(customerId = 'c1', n = 5, amount = 10000, first = '2026-10-23'): Installment[] {
  return Array.from({ length: n }, (_, i) => ({
    id: `${customerId}-i${i + 1}`, customerId, sequence: i + 1,
    dueDate: new Date(Date.parse(first + 'T00:00:00Z') + i * 86400000).toISOString().slice(0, 10),
    scheduledAmount: amount, allocatedAmount: 0, lastPaymentDate: null, state: 'active' as const,
  }));
}
export function setup(opts: { allowAdvance?: boolean } = {}) {
  const repo = new InMemoryRepo();
  repo.seedCustomer({ id: 'c1', businessId: BIZ, assignedEmployeeId: 'emp-a', status: 'active', creditBalance: 0 }, makeInstallments());
  const service = new PaymentService(repo, { verificationSecret: 'test-secret', now: () => new Date('2026-10-23T08:00:00+08:00'), allowAdvance: opts.allowAdvance });
  return { repo, service };
}
let n = 0;
export function pay(over: Partial<PaymentInput> = {}): PaymentInput {
  n++;
  return { businessId: BIZ, customerId: 'c1', employeeId: 'emp-a', amount: 10000, method: 'cash', paidAt: '2026-10-23T09:00:00+08:00',
    deviceTransactionId: `dev-txn-${n}`, receiptNo: `OR-EMPA-D1-20261023-${String(n).padStart(4, '0')}`, recordedOffline: false, ...over };
}

import type { PaymentRecord } from '../src/types.ts';
let pid = 0;
/** A stored payment record without going through the service (for report/dashboard tests). */
export function fakePayment(over: Partial<PaymentRecord> = {}): PaymentRecord {
  pid++;
  const paidAt = over.paidAt ?? '2026-10-23T09:00:00+08:00';
  return { id: `p${String(pid).padStart(3, '0')}`, businessId: BIZ, customerId: 'c1', employeeId: 'emp-a', amount: 10000, method: 'cash', paidAt,
    deviceTransactionId: `d${pid}`, receiptNo: `R${pid}`, verificationCode: 'XXXXX-XXXXX', reference: null, note: null, location: null,
    recordedOffline: false, syncedAt: paidAt, allocations: [], creditAmount: 0, ...over };
}
